// Avoid Windows min/max macros breaking std::min/std::max
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "winmf_provider.h"
#include "dshow_signal_probe.h"
#include "../pipeline/shared_scene_pipeline.h"
#include "mf_recorder.h"
#include <mferror.h>
#include <cassert>
#include <chrono>
#include <condition_variable>
#include <algorithm>
#include <sstream>
#include <comdef.h>  // for _com_error
#include <windows.h> // for OutputDebugStringA
#include <string>
#include <thread>
#include <mutex>
#include <deque>
#include <atomic>
#include <condition_variable>

#include <setupapi.h>
#include <devpkey.h>
#include <dshow.h>
#include <dvdmedia.h>
#include <cmath>
namespace
{
    // DEVPROPKEY = { fmtid(GUID), pid }
    static const DEVPROPKEY kDevPKey_Device_DriverVersion = {
        {0xa8b865dd, 0x2e3d, 0x4094, {0xad, 0x97, 0xe5, 0x93, 0xa7, 0x0c, 0x75, 0xd6}},
        3};

    static const DEVPROPKEY kDevPKey_Device_FirmwareVersion = {
        {0xa8b865dd, 0x2e3d, 0x4094, {0xad, 0x97, 0xe5, 0x93, 0xa7, 0x0c, 0x75, 0xd6}},
        4};

    static const DEVPROPKEY kDevPKey_Device_SerialNumber = {
        {0x78c34fc8, 0x104a, 0x4aca, {0x9e, 0xa4, 0x52, 0x4d, 0x52, 0x99, 0x6e, 0x57}},
        256};
}
#pragma comment(lib, "setupapi.lib")
#include "../core/frame_converter.h"

using Microsoft::WRL::ComPtr;

static std::string hr_msg(HRESULT hr)
{
    _com_error ce(hr);

    const wchar_t *wmsg =
        ce.ErrorMessage() ? ce.ErrorMessage() : L"unknown";

    // wchar_t → UTF-8 std::string
    int len = WideCharToMultiByte(
        CP_UTF8, 0,
        wmsg, -1,
        nullptr, 0,
        nullptr, nullptr);

    std::string msg(len - 1, '\0');
    WideCharToMultiByte(
        CP_UTF8, 0,
        wmsg, -1,
        msg.data(), len,
        nullptr, nullptr);

    std::ostringstream oss;
    oss << "hr=0x"
        << std::hex << std::uppercase << (unsigned long)hr
        << " (" << msg << ")";
    return oss.str();
}

// --- local helper: wide string -> UTF-8 string ---
static std::string wide_to_utf8(const std::wstring &ws)
{
    if (ws.empty())
        return {};

    const int len = WideCharToMultiByte(CP_UTF8, 0,
                                        ws.c_str(), -1,
                                        nullptr, 0,
                                        nullptr, nullptr);
    if (len <= 0)
        return {};

    std::string out((size_t)len - 1, '\0');
    WideCharToMultiByte(CP_UTF8, 0,
                        ws.c_str(), -1,
                        out.data(), len,
                        nullptr, nullptr);
    return out;
}

// --- compatibility: 讓你檔案裡原本的 utf8_from_wide(...) 全部不用改 ---
static std::string utf8_from_wide(const std::wstring &ws)
{
    return wide_to_utf8(ws);
}

static gcap_pixfmt_t mfsub_to_gcap(const GUID &sub)
{
    if (sub == MFVideoFormat_NV12)
        return GCAP_FMT_NV12;
    if (sub == MFVideoFormat_YUY2)
        return GCAP_FMT_YUY2;
    if (sub == MFVideoFormat_P010)
        return GCAP_FMT_P010;
    if (sub == MFVideoFormat_Y210)
        return GCAP_FMT_Y210;
    if (sub == MFVideoFormat_ARGB32)
        return GCAP_FMT_ARGB;
    return GCAP_FMT_ARGB; // fallback（你也可改成 NV12）
}

static int pixfmt_bitdepth(gcap_pixfmt_t f)
{
    switch (f)
    {
    case GCAP_FMT_P010:
    case GCAP_FMT_Y210:
    case GCAP_FMT_R210:
    case GCAP_FMT_V210:
        return 10;
    default:
        return 8;
    }
}

static std::wstring get_mf_string(IMFActivate *act, const GUID &key)
{
    if (!act)
        return {};
    wchar_t *w = nullptr;
    UINT32 cch = 0;
    if (FAILED(act->GetAllocatedString(key, &w, &cch)) || !w)
        return {};
    std::wstring s(w);
    CoTaskMemFree(w);
    return s;
}

static bool setupapi_open_by_interface(const std::wstring &symLink, HDEVINFO &outSet, SP_DEVINFO_DATA &outDevInfo)
{
    outSet = SetupDiCreateDeviceInfoList(nullptr, nullptr);
    if (outSet == INVALID_HANDLE_VALUE)
        return false;

    SP_DEVICE_INTERFACE_DATA ifData{};
    ifData.cbSize = sizeof(ifData);
    if (!SetupDiOpenDeviceInterfaceW(outSet, symLink.c_str(), 0, &ifData))
        return false;

    DWORD required = 0;
    SetupDiGetDeviceInterfaceDetailW(outSet, &ifData, nullptr, 0, &required, nullptr);
    if (required == 0)
        return false;

    std::vector<uint8_t> buf(required);
    auto *detail = reinterpret_cast<SP_DEVICE_INTERFACE_DETAIL_DATA_W *>(buf.data());
    detail->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA_W);

    outDevInfo = {};
    outDevInfo.cbSize = sizeof(outDevInfo);
    if (!SetupDiGetDeviceInterfaceDetailW(outSet, &ifData, detail, required, nullptr, &outDevInfo))
        return false;

    return true;
}

static std::wstring setupapi_get_prop_string(HDEVINFO set, SP_DEVINFO_DATA &devInfo, const DEVPROPKEY &key)
{
    DEVPROPTYPE type = 0;
    DWORD bytes = 0;
    SetupDiGetDevicePropertyW(set, &devInfo, &key, &type, nullptr, 0, &bytes, 0);
    if (bytes == 0)
        return {};
    std::vector<uint8_t> buf(bytes);
    if (!SetupDiGetDevicePropertyW(set, &devInfo, &key, &type, buf.data(), (DWORD)buf.size(), &bytes, 0))
        return {};
    if (type != DEVPROP_TYPE_STRING)
        return {};
    return std::wstring(reinterpret_cast<wchar_t *>(buf.data()));
}

bool WinMFProvider::getDeviceProps(gcap_device_props_t &out)
{
    memset(&out, 0, sizeof(out));

    strncpy_s(out.driver_version, sizeof(out.driver_version), "Unknown", _TRUNCATE);
    strncpy_s(out.firmware_version, sizeof(out.firmware_version), "Unknown", _TRUNCATE);
    strncpy_s(out.serial_number, sizeof(out.serial_number), "Unknown", _TRUNCATE);

    if (dev_sym_link_w_.empty())
        return true;

    HDEVINFO set = INVALID_HANDLE_VALUE;
    SP_DEVINFO_DATA devInfo{};
    if (!setupapi_open_by_interface(dev_sym_link_w_, set, devInfo))
    {
        if (set != INVALID_HANDLE_VALUE)
            SetupDiDestroyDeviceInfoList(set);
        return true;
    }

    std::wstring drvVer =
        setupapi_get_prop_string(set, devInfo, kDevPKey_Device_DriverVersion);
    std::wstring fwVer =
        setupapi_get_prop_string(set, devInfo, kDevPKey_Device_FirmwareVersion);
    std::wstring sn =
        setupapi_get_prop_string(set, devInfo, kDevPKey_Device_SerialNumber);

    if (!drvVer.empty())
    {
        auto s = wide_to_utf8(drvVer);
        strncpy_s(out.driver_version, sizeof(out.driver_version), s.c_str(), _TRUNCATE);
    }

    if (!fwVer.empty())
    {
        auto s = wide_to_utf8(fwVer);
        strncpy_s(out.firmware_version, sizeof(out.firmware_version), s.c_str(), _TRUNCATE);
    }

    if (!sn.empty())
    {
        auto s = wide_to_utf8(sn);
        strncpy_s(out.serial_number, sizeof(out.serial_number), s.c_str(), _TRUNCATE);
    }

    SetupDiDestroyDeviceInfoList(set);
    return true;
}

bool WinMFProvider::refresh_signal_probe(bool force)
{
    if (current_index_ < 0)
        return false;

    const auto nowMs = (uint64_t)std::chrono::duration_cast<std::chrono::milliseconds>(
                           std::chrono::steady_clock::now().time_since_epoch())
                           .count();
    if (!force && signal_valid_ && (nowMs - last_signal_probe_ms_ < 1000))
        return true;

    DShowSignalProbeResult probe{};
    if (dshow_probe_current_signal_by_index(current_index_, probe) && probe.ok)
    {
        signal_valid_ = true;
        signal_w_ = probe.width;
        signal_h_ = probe.height;
        signal_fps_num_ = probe.fps_num;
        signal_fps_den_ = (probe.fps_den > 0) ? probe.fps_den : 1;
        signal_subtype_ = probe.subtype;
        last_signal_probe_ms_ = nowMs;
        return true;
    }

    signal_valid_ = false;
    last_signal_probe_ms_ = nowMs;
    return false;
}

bool WinMFProvider::getSignalStatus(gcap_signal_status_t &out)
{
    refresh_signal_probe(false);

    memset(&out, 0, sizeof(out));

    const bool useSignal = signal_valid_ && signal_w_ > 0 && signal_h_ > 0;
    out.width = useSignal ? signal_w_ : cur_w_;
    out.height = useSignal ? signal_h_ : cur_h_;
    out.fps_num = useSignal ? signal_fps_num_ : ((cur_fps_num_ > 0) ? cur_fps_num_ : 0);
    out.fps_den = useSignal ? signal_fps_den_ : ((cur_fps_den_ > 0) ? cur_fps_den_ : 1);
    out.pixfmt = mfsub_to_gcap(useSignal ? signal_subtype_ : cur_subtype_);
    out.bit_depth = pixfmt_bitdepth(out.pixfmt);
    out.csp = GCAP_CSP_UNKNOWN;
    out.range = GCAP_RANGE_UNKNOWN;
    out.hdr = -1;
    return (out.width > 0 && out.height > 0);
}

bool WinMFProvider::getRuntimeInfo(gcap_runtime_info_t &out)
{
    memset(&out, 0, sizeof(out));
    if (!getSignalStatus(out.signal))
        return false;

    memset(&out.negotiated, 0, sizeof(out.negotiated));
    out.negotiated.width = cur_w_;
    out.negotiated.height = cur_h_;
    out.negotiated.fps_num = cur_fps_num_;
    out.negotiated.fps_den = cur_fps_den_;
    out.negotiated.pixfmt = mfsub_to_gcap(cur_subtype_);
    out.negotiated.bit_depth = pixfmt_bitdepth(out.negotiated.pixfmt);
    out.negotiated.csp = GCAP_CSP_UNKNOWN;
    out.negotiated.range = GCAP_RANGE_UNKNOWN;
    out.negotiated.hdr = -1;

    const bool gpu = isUsingGpu();
    out.runtime_fps = fps_avg_;
    out.active_backend = gpu ? GCAP_BACKEND_WINMF_GPU : GCAP_BACKEND_WINMF_CPU;
    strcpy_s(out.backend_name, gpu ? "WinMF GPU" : "WinMF CPU");
    strcpy_s(out.frame_source, gpu ? "DXGI" : "CPU");
    strcpy_s(out.path_name, gpu ? "WinMF GPU Preview" : "WinMF CPU Preview");
    strcpy_s(out.source_format, gcap_subtype_name(cur_subtype_));
    strcpy_s(out.render_format, gpu ? "FP16 Scene" : "BGRA8 CPU");
    return true;
}

bool WinMFProvider::setProcessing(const gcap_processing_opts_t &opts)
{
    (void)opts;
    // 先回不支援：等你要做「切 NV12/YUY2/P010 / Deinterlace」再補 setProfile / rebuild reader
    return false;
}

bool WinMFProvider::setProcAmp(const gcap_procamp_t &p)
{
    // Clamp to 0..255 just in case caller passes out-of-range.
    auto clamp255 = [](int v) -> int
    { return std::clamp(v, 0, 255); };

    procamp_.brightness = clamp255(p.brightness);
    procamp_.contrast = clamp255(p.contrast);
    procamp_.hue = clamp255(p.hue);
    procamp_.saturation = clamp255(p.saturation);
    procamp_.sharpness = clamp255(p.sharpness);
    return true;
}

// ---- logging helpers (for negotiated media type / stride debug) ----
static const char *mf_subtype_name(const GUID &g)
{
    if (g == MFVideoFormat_NV12)
        return "NV12";
    if (g == MFVideoFormat_P010)
        return "P010";
    if (g == MFVideoFormat_YUY2)
        return "YUY2";
    if (g == MFVideoFormat_Y210)
        return "Y210";
    if (g == MFVideoFormat_ARGB32)
        return "ARGB32";
    if (g == MFVideoFormat_RGB32)
        return "RGB32";
    if (g == MFVideoFormat_MJPG)
        return "MJPG";
    return "(unknown)";
}

static int mf_default_stride_bytes(IMFMediaType *mt)
{
    if (!mt)
        return 0;
    UINT32 raw = 0;
    if (FAILED(mt->GetUINT32(MF_MT_DEFAULT_STRIDE, &raw)))
        return 0;
    // MF_MT_DEFAULT_STRIDE is effectively an INT32 stored in a UINT32 container.
    int s = (int)(int32_t)raw;
    return s < 0 ? -s : s;
}

// UTF-8 → UTF-16 (wstring) 工具，用來把檔名丟給 Media Foundation
static std::wstring utf8_to_wstring(const char *s)
{
    if (!s)
        return std::wstring();
    int len = MultiByteToWideChar(CP_UTF8, 0, s, -1, nullptr, 0);
    if (len <= 0)
        return std::wstring();
    std::wstring ws(len - 1, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s, -1, &ws[0], len);
    return ws;
}

gcap_status_t WinMFProvider::startRecording(const char *pathUtf8)
{
    std::lock_guard<std::mutex> lock(recorderMutex_);

    if (!reader_) // 尚未 open / start
        return GCAP_ESTATE;

    if (!pathUtf8 || !*pathUtf8)
        return GCAP_EINVAL;

    // 目前只支援 NV12 / P010 兩種 YUV 型態
    bool isP010Format = false;
    if (cur_subtype_ == MFVideoFormat_P010)
    {
        isP010Format = true;
    }
    else if (cur_subtype_ == MFVideoFormat_NV12)
    {
        isP010Format = false;
    }
    else
    {
        return GCAP_ENOTSUP;
    }

    if (!recorder_)
        recorder_ = std::make_unique<MfRecorder>();

    UINT32 w = static_cast<UINT32>(cur_w_);
    UINT32 h = static_cast<UINT32>(cur_h_);
    UINT32 fpsN = profile_.fps_num ? profile_.fps_num : 60;
    UINT32 fpsD = profile_.fps_den ? profile_.fps_den : 1;

    std::wstring wpath = utf8_to_wstring(pathUtf8);
    // recording audio endpoint (empty => default)
    std::wstring audioIdW;
    if (!rec_audio_device_id_.empty())
        audioIdW = utf8_to_wstring(rec_audio_device_id_.c_str());

    if (!recorder_->open(wpath, w, h, fpsN, fpsD, isP010Format, audioIdW))
        return GCAP_EIO;

    OutputDebugStringA("[WinMF] Recorder: startRecording()\\n");
    return GCAP_OK;
}

gcap_status_t WinMFProvider::stopRecording()
{
    std::lock_guard<std::mutex> lock(recorderMutex_);

    if (recorder_)
    {
        recorder_->close();
        OutputDebugStringA("[WinMF] Recorder: stopRecording()\\n");
    }
    return GCAP_OK;
}

gcap_status_t WinMFProvider::setRecordingAudioDevice(const char *device_id_utf8)
{
    std::lock_guard<std::mutex> lock(recorderMutex_);

    // Only affects next startRecording call.
    rec_audio_device_id_.clear();
    if (device_id_utf8 && *device_id_utf8)
        rec_audio_device_id_ = device_id_utf8;

    OutputDebugStringA("[WinMF] Recorder audio endpoint set\n");
    return GCAP_OK;
}

#define DBG(stage, hr)                                                          \
    do                                                                          \
    {                                                                           \
        std::string __m = std::string("[WinMF] ") + stage + " : " + hr_msg(hr); \
        OutputDebugStringA((__m + "\n").c_str());                               \
    } while (0)

// Member-scope debug: also forward to app log (via emit_error(GCAP_OK,...)).
// IMPORTANT: Only use inside WinMFProvider member functions (where `this` exists).
#define MDBG(stage, hr)                                                         \
    do                                                                          \
    {                                                                           \
        std::string __m = std::string("[WinMF] ") + stage + " : " + hr_msg(hr); \
        this->emit_error(GCAP_OK, __m.c_str());                                 \
    } while (0)

static void ensure_mf()
{
    static std::once_flag f;
    std::call_once(f, []
                   {
        HRESULT hr = CoInitializeEx(nullptr, COINIT_MULTITHREADED);
        // 如果已經被其他人用不同 apartment 初始化（常見 0x80010106），直接忽略即可
        if (hr != S_OK && hr != S_FALSE && hr != RPC_E_CHANGED_MODE) {
            DBG("CoInitializeEx", hr);
        }

        hr = MFStartup(MF_VERSION, MFSTARTUP_FULL);
        if (FAILED(hr)) {
            DBG("MFStartup", hr);
            // 這通常是 Windows N/Server 未裝 Media Feature Pack
            OutputDebugStringA("[WinMF] Media Foundation platform not initialized. Check 'Media Features' / Media Feature Pack.\n");
        } });
}

// 初始預設使用系統 default adapter（-1）
std::atomic<int> WinMFProvider::s_adapter_index_{-1};

void WinMFProvider::setPreferredAdapterIndex(int index)
{
    s_adapter_index_.store(index, std::memory_order_relaxed);
}

WinMFProvider::WinMFProvider(bool preferGpu)
    : prefer_gpu_(preferGpu), pipeline_(std::make_unique<SharedScenePipeline>())
{
}

WinMFProvider::~WinMFProvider()
{
    stop();
    close();
}

void WinMFProvider::emit_error(gcap_status_t c, const char *msg)
{
    if (ecb_)
    {
        ecb_(c, msg, user_);
        return;
    }

    // callbacks 尚未設定：只暫存 GCAP_OK 的 debug 訊息（避免把錯誤吞掉）
    if (c == GCAP_OK && msg)
        pending_log_push(msg);
}

void WinMFProvider::pending_log_push(const char *msg)
{
    std::lock_guard<std::mutex> lk(pending_mtx_);
    if (pending_logs_.size() >= kMaxPendingLogs)
        pending_logs_.pop_front();
    pending_logs_.emplace_back(msg);
}

void WinMFProvider::pending_log_flush()
{
    // 把暫存 log 取出（避免在 lock 內呼叫 callback）
    std::deque<std::string> tmp;
    {
        std::lock_guard<std::mutex> lk(pending_mtx_);
        tmp.swap(pending_logs_);
    }

    if (!ecb_)
        return;

    for (auto &s : tmp)
        ecb_(GCAP_OK, s.c_str(), user_);
}

bool WinMFProvider::enumerate(std::vector<gcap_device_info_t> &list)
{
    ensure_mf();
    ComPtr<IMFAttributes> attr;
    if (FAILED(MFCreateAttributes(&attr, 1)))
        return false;
    attr->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);

    IMFActivate **pp = nullptr;
    UINT32 count = 0;
    if (FAILED(MFEnumDeviceSources(attr.Get(), &pp, &count)))
        return false;

    list.clear();
    for (UINT32 i = 0; i < count; ++i)
    {
        gcap_device_info_t di{};
        di.index = (int)i;
        di.caps = 0;

        // Friendly name
        std::wstring wname = get_mf_string(pp[i], MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME);
        if (!wname.empty())
        {
            std::string s = utf8_from_wide(wname.c_str());
            strncpy(di.name, s.c_str(), sizeof(di.name) - 1);
        }

        // Symbolic link（給後續查 Driver/FW/Serial）
        std::wstring wlink = get_mf_string(pp[i], MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK);
        if (!wlink.empty())
        {
            std::string s = utf8_from_wide(wlink.c_str());
            strncpy(di.symbolic_link, s.c_str(), sizeof(di.symbolic_link) - 1);
        }

        list.push_back(di);
        pp[i]->Release();
    }
    CoTaskMemFree(pp);
    return true;
}

bool WinMFProvider::create_reader_cpu_only(int devIndex)
{
    // enumerate & activate
    ComPtr<IMFAttributes> attr;
    if (FAILED(MFCreateAttributes(&attr, 1)))
        return false;
    attr->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);

    IMFActivate **pp = nullptr;
    UINT32 count = 0;
    HRESULT hr = MFEnumDeviceSources(attr.Get(), &pp, &count);
    if (FAILED(hr) || (UINT32)devIndex >= count)
    {
        if (pp)
        {
            for (UINT32 i = 0; i < count; ++i)
                pp[i]->Release();
            CoTaskMemFree(pp);
        }
        return false;
    }
    hr = pp[devIndex]->ActivateObject(__uuidof(IMFMediaSource),
                                      (void **)source_.ReleaseAndGetAddressOf());

    // 讀 FriendlyName 存到 dev_name_
    {
        std::wstring wname = get_mf_string(pp[devIndex], MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME);
        if (!wname.empty())
            dev_name_ = utf8_from_wide(wname.c_str());
        dev_sym_link_w_ = get_mf_string(pp[devIndex], MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK);
    }

    for (UINT32 i = 0; i < count; ++i)
        pp[i]->Release();
    CoTaskMemFree(pp);
    if (FAILED(hr))
    {
        DBG("ActivateObject(IMFMediaSource)", hr);
        return false;
    }

    // 關鍵：啟用 Video Processing（讓 MFT 幫我們解 MJPG/轉色彩）
    ComPtr<IMFAttributes> rdAttr;
    hr = MFCreateAttributes(&rdAttr, 1);
    if (FAILED(hr))
    {
        DBG("MFCreateAttributes(reader)", hr);
        return false;
    }
    rdAttr->SetUINT32(MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, TRUE);

    hr = MFCreateSourceReaderFromMediaSource(source_.Get(), rdAttr.Get(), &reader_);
    if (FAILED(hr))
    {
        DBG("CreateReader CPU+VP", hr);
        return false;
    }

    return true;
}

bool WinMFProvider::open(int index)
{
    ensure_mf();
    current_index_ = index;
    signal_valid_ = false;
    signal_w_ = signal_h_ = 0;
    signal_fps_num_ = 0;
    signal_fps_den_ = 1;
    signal_subtype_ = GUID_NULL;
    last_signal_probe_ms_ = 0;

    if (prefer_gpu_)
    {
        // 先試 GPU + DXGI 管線
        if (create_d3d() && create_reader_with_dxgi(index) && use_dxgi_)
        {
            // 先嘗試強制協商成 NV12（協商不到就維持 device default，可能是 YUY2）
            // OBS-style: 不選最大 native format，直接使用裝置 default
            ComPtr<IMFMediaType> cur;
            if (SUCCEEDED(reader_->GetCurrentMediaType(
                    MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur)))
            {
                ComPtr<IMFMediaType> req;
                if (SUCCEEDED(MFCreateMediaType(&req)))
                {
                    req->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
                    req->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
                    HRESULT hrSet = reader_->SetCurrentMediaType(
                        MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, req.Get());
                    if (SUCCEEDED(hrSet))
                    {
                        // 重新讀回實際 negotiated（通常會變 NV12）
                        reader_->GetCurrentMediaType(
                            MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur);
                    }
                }

                UINT32 w = 0, h = 0, fn = 0, fd = 1;
                MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &w, &h);
                MFGetAttributeRatio(cur.Get(), MF_MT_FRAME_RATE, &fn, &fd);
                cur->GetGUID(MF_MT_SUBTYPE, &cur_subtype_);

                cur_w_ = (int)w;
                cur_h_ = (int)h;
                cpu_path_ = false;

                ensure_rt_and_pipeline(cur_w_, cur_h_);

                refresh_signal_probe(true);
                emit_error(GCAP_OK,
                           "[WinMF] Using device default format (OBS-style)");
                return true;
            }
        }
    }

    // ---- CPU fallback ----
    reader_.Reset();
    source_.Reset();
    use_dxgi_ = false;
    cpu_path_ = true;

    // 只建立 CPU + Video Processing 的 reader
    if (!create_reader_cpu_only(index))
    {
        emit_error(GCAP_EIO, "Create reader (CPU) failed");
        OutputDebugStringA("[WinMF] open(): Create reader (CPU) failed\n");
        return false;
    }

    // 先嘗試把輸出設成 NV12，不行再 ARGB32
    {
        ComPtr<IMFMediaType> mt;
        MFCreateMediaType(&mt);
        mt->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
        mt->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
        HRESULT hr = reader_->SetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, mt.Get());
        if (FAILED(hr))
        {
            DBG("SetCurrentMediaType(NV12)", hr);
            ComPtr<IMFMediaType> mt2;
            MFCreateMediaType(&mt2);
            mt2->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
            mt2->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_ARGB32);
            hr = reader_->SetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, mt2.Get());
            if (FAILED(hr))
            {
                DBG("SetCurrentMediaType(ARGB32)", hr);
                // 兩個都失敗就不硬設，直接用裝置預設型態
            }
        }
    }

    // 讀回實際型態，更新 cur_* 給 CPU 路使用
    ComPtr<IMFMediaType> cur;
    if (FAILED(reader_->GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur)))
    {
        emit_error(GCAP_EIO, "GetCurrentMediaType failed");
        return false;
    }

    UINT32 w = 0, h = 0, fn = 0, fd = 1;
    MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &w, &h);
    MFGetAttributeRatio(cur.Get(), MF_MT_FRAME_RATE, &fn, &fd);
    cur_w_ = (int)w;
    cur_h_ = (int)h;

    cur->GetGUID(MF_MT_SUBTYPE, &cur_subtype_);

    // negotiated stride (very important for capture cards with aligned rows)
    cur_stride_ = mf_default_stride_bytes(cur.Get());
    if (cur_stride_ <= 0)
    {
        if (cur_subtype_ == MFVideoFormat_P010)
            cur_stride_ = cur_w_ * 2;
        else if (cur_subtype_ == MFVideoFormat_ARGB32)
            cur_stride_ = cur_w_ * 4;
        else
            cur_stride_ = cur_w_;
    }

    // negotiated media type (CPU/VP path)
    {
        std::ostringstream oss;
        oss << "[WinMF] negotiated (CPU/VP): dev='" << dev_name_ << "'"
            << ", subtype=" << mf_subtype_name(cur_subtype_)
            << ", " << cur_w_ << "x" << cur_h_
            << " @ " << fn;
        if (fd != 1)
            oss << "/" << fd;
        oss << " fps"
            << ", default_stride=" << cur_stride_ << " bytes";
        emit_error(GCAP_OK, oss.str().c_str());
    }

    // 只開第一個視訊串流
    reader_->SetStreamSelection(MF_SOURCE_READER_ALL_STREAMS, FALSE);
    reader_->SetStreamSelection(MF_SOURCE_READER_FIRST_VIDEO_STREAM, TRUE);

    refresh_signal_probe(true);

    OutputDebugStringA("[WinMF] open(): using CPU pipeline\n");
    emit_error(GCAP_OK, "[WinMF] open(): using CPU pipeline");
    return true;
}

bool WinMFProvider::setProfile(const gcap_profile_t &p)
{
    profile_ = p;

    // OBS-style: Device Default 不強制設定解析度
    if (p.mode == GCAP_PROFILE_DEVICE_DEFAULT)
        return true;

    if (!reader_)
        return true;

    ComPtr<IMFMediaType> mt;
    if (FAILED(MFCreateMediaType(&mt)))
        return false;

    mt->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    mt->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_NV12);
    MFSetAttributeSize(mt.Get(), MF_MT_FRAME_SIZE, p.width, p.height);
    MFSetAttributeRatio(mt.Get(), MF_MT_FRAME_RATE,
                        p.fps_num ? p.fps_num : 60,
                        p.fps_den ? p.fps_den : 1);
    MFSetAttributeRatio(mt.Get(), MF_MT_PIXEL_ASPECT_RATIO, 1, 1);

    HRESULT hr = reader_->SetCurrentMediaType(
        MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, mt.Get());

    if (FAILED(hr))
    {
        emit_error(GCAP_OK,
                   "[WinMF] Custom profile rejected, fallback to device default");
        return false;
    }

    emit_error(GCAP_OK, "[WinMF] Custom profile applied");

    return true;
}
bool WinMFProvider::setBuffers(int, size_t) { return true; }

bool WinMFProvider::start()
{
    if (running_)
        return true;
    running_ = true;
    th_ = std::thread(&WinMFProvider::loop, this);
    return true;
}

void WinMFProvider::stop()
{
    if (!running_)
        return;
    running_ = false;
    if (th_.joinable())
        th_.join();
    if (pipeline_)
        pipeline_->release_preview_swapchain();
}

void WinMFProvider::close()
{
    stopRecording();
    reader_.Reset();
    source_.Reset();
    if (pipeline_)
        pipeline_->shutdown();
    d2d_ctx_.Reset();
    d2d_device_.Reset();
    d2d_factory_.Reset();
    dwrite_.Reset();
    pipeline_->samp_.Reset();
    pipeline_->vb_.Reset();
    pipeline_->il_.Reset();
    pipeline_->vs_.Reset();
    pipeline_->ps_nv12_.Reset();
    pipeline_->ps_p010_.Reset();
    pipeline_->ps_yuy2_.Reset();
    pipeline_->ps_y210_.Reset();
    pipeline_->ps_fp16_to_rgba8_.Reset();
    pipeline_->ps_fp16_to_preview_.Reset();
    pipeline_->ps_composite_overlay_fp16_.Reset();
    cs_nv12_.Reset();
    pipeline_->cs_params_.Reset();
    pipeline_->rt_uav_.Reset();
    upload_yuy2_packed_.Reset();
    upload_y210_packed_.Reset();

    if (dxgi_mgr_)
        dxgi_mgr_.Reset();
    ctx1_.Reset();
    d3d1_.Reset();
    ctx_.Reset();
    d3d_.Reset();

    current_index_ = -1;
    signal_valid_ = false;
    signal_w_ = signal_h_ = 0;
    signal_fps_num_ = 0;
    signal_fps_den_ = 1;
    signal_subtype_ = GUID_NULL;
    last_signal_probe_ms_ = 0;
}

void WinMFProvider::setCallbacks(gcap_on_video_cb vcb, gcap_on_error_cb ecb, void *user)
{
    vcb_ = vcb;
    ecb_ = ecb;
    user_ = user;
    // callbacks 設定完成後，把 open() 階段的 pending logs 一次吐出
    pending_log_flush();
}

void WinMFProvider::setFramePacketCallback(gcap_on_frame_packet_cb pcb, void *user)
{
    pcb_ = pcb;
    user_ = user;
}

static inline void emit_frame_packet_cb(gcap_on_frame_packet_cb pcb, void *user,
                                        int backend, int sourceKind, int gpuBacked,
                                        const gcap_frame_t &f)
{
    if (!pcb)
        return;
    gcap_frame_packet_t pkt{};
    pkt.width = f.width;
    pkt.height = f.height;
    pkt.format = f.format;
    pkt.plane_count = f.plane_count;
    for (int i = 0; i < 3; ++i)
    {
        pkt.data[i] = f.data[i];
        pkt.stride[i] = f.stride[i];
    }
    pkt.pts_ns = f.pts_ns;
    pkt.frame_id = f.frame_id;
    pkt.backend = backend;
    pkt.source_kind = sourceKind;
    pkt.gpu_backed = gpuBacked;
    pcb(&pkt, user);
}

// -------------------- D3D / MF init --------------------

bool WinMFProvider::create_d3d()
{
    UINT flags = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#ifdef _DEBUG
    flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

    D3D_FEATURE_LEVEL fls[] = {D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0};
    D3D_FEATURE_LEVEL got{};

    // 目前選擇的 Adapter index（由 UI 經由 C API 設定）
    const int wantAdapter = s_adapter_index_.load(std::memory_order_relaxed);

    auto try_create = [&](IDXGIAdapter1 *adapter, UINT fl) -> HRESULT
    {
        return D3D11CreateDevice(adapter,
                                 adapter ? D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE,
                                 nullptr,
                                 fl,
                                 fls,
                                 _countof(fls),
                                 D3D11_SDK_VERSION,
                                 &d3d_,
                                 &got,
                                 &ctx_);
    };

    HRESULT hr = E_FAIL;

    // 1) 如果有指定 Adapter index，先嘗試用該張 GPU 建 device
    if (wantAdapter >= 0)
    {
        ComPtr<IDXGIFactory1> fac;
        hr = CreateDXGIFactory1(__uuidof(IDXGIFactory1), reinterpret_cast<void **>(fac.GetAddressOf()));
        if (SUCCEEDED(hr) && fac)
        {
            ComPtr<IDXGIAdapter1> ad;
            hr = fac->EnumAdapters1(static_cast<UINT>(wantAdapter), &ad);
            if (SUCCEEDED(hr) && ad)
            {
                hr = try_create(ad.Get(), flags);
#ifdef _DEBUG
                if (FAILED(hr))
                {
                    // 失敗時移除 DEBUG 再試一次
                    flags &= ~D3D11_CREATE_DEVICE_DEBUG;
                    hr = try_create(ad.Get(), flags);
                }
#endif
                if (FAILED(hr))
                {
                    DBG("D3D11CreateDevice(adapter) failed, fallback to default", hr);
                }
            }
            else
            {
                DBG("EnumAdapters1(wantAdapter) failed, fallback to default", hr);
            }
        }
    }

    // 2) 如果沒有指定，或指定失敗 → 回到原本的 default adapter 流程
    if (!d3d_)
    {
        hr = try_create(nullptr, flags);
#ifdef _DEBUG
        if (FAILED(hr))
        {
            // 自動移除 DEBUG 再試一次
            flags &= ~D3D11_CREATE_DEVICE_DEBUG;
            hr = try_create(nullptr, flags);
        }
#endif
        if (FAILED(hr))
        {
            DBG("D3D11CreateDevice(default)", hr);
            return false;
        }
    }

    d3d_.As(&d3d1_);
    ctx_.As(&ctx1_);
    d3d_.As(&d3d1_);
    ctx_.As(&ctx1_);

    // 取得實際使用的 GPU 名稱，之後在 NV12→RGBA overlay 顯示
    gpu_name_w_.clear();
    {
        ComPtr<IDXGIDevice> dxDev;
        if (SUCCEEDED(d3d_.As(&dxDev)) && dxDev)
        {
            ComPtr<IDXGIAdapter> ad;
            if (SUCCEEDED(dxDev->GetAdapter(&ad)) && ad)
            {
                DXGI_ADAPTER_DESC desc{};
                if (SUCCEEDED(ad->GetDesc(&desc)))
                {
                    gpu_name_w_ = desc.Description; // wchar_t[128]
                }
            }
        }
    }

    if (FAILED(MFCreateDXGIDeviceManager(&dxgi_token_, &dxgi_mgr_)))
    {
        DBG("MFCreateDXGIDeviceManager", E_FAIL);
        return false;
    }

    ComPtr<IDXGIDevice> dx;
    d3d_.As(&dx);
    if (FAILED(dxgi_mgr_->ResetDevice(dx.Get(), dxgi_token_)))
    {
        DBG("DXGI ResetDevice", E_FAIL);
        return false;
    }

    // D2D / DWrite
    if (FAILED(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, d2d_factory_.ReleaseAndGetAddressOf())))
        return false;
    ComPtr<IDXGIDevice> dxgiDev;
    d3d_.As(&dxgiDev);
    if (FAILED(d2d_factory_->CreateDevice(dxgiDev.Get(), &d2d_device_)))
        return false;
    if (FAILED(d2d_device_->CreateDeviceContext(D2D1_DEVICE_CONTEXT_OPTIONS_NONE, &d2d_ctx_)))
        return false;
    if (FAILED(DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), &dwrite_)))
        return false;
    d2d_ctx_->CreateSolidColorBrush(D2D1::ColorF(1, 1, 1, 1), &d2d_white_);
    d2d_ctx_->CreateSolidColorBrush(D2D1::ColorF(0, 0, 0, 0.55f), &d2d_black_);
    if (pipeline_)
        pipeline_->initialize(d3d_.Get(), ctx_.Get(), d2d_ctx_.Get(), dwrite_.Get(), d2d_white_.Get(), d2d_black_.Get());
    return true;
}

bool WinMFProvider::create_reader_with_dxgi(int devIndex)
{
    use_dxgi_ = false; // 預設關掉 DXGI
    cpu_path_ = true;

    auto activate_source = [&](ComPtr<IMFMediaSource> &out) -> HRESULT
    {
        out.Reset();
        ComPtr<IMFAttributes> attr;
        HRESULT hr = MFCreateAttributes(&attr, 1);
        if (FAILED(hr))
            return hr;
        attr->SetGUID(MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE, MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_GUID);

        IMFActivate **pp = nullptr;
        UINT32 count = 0;
        hr = MFEnumDeviceSources(attr.Get(), &pp, &count);
        if (FAILED(hr) || (UINT32)devIndex >= count)
        {
            if (pp)
            {
                for (UINT32 i = 0; i < count; ++i)
                    pp[i]->Release();
                CoTaskMemFree(pp);
            }
            return FAILED(hr) ? hr : E_INVALIDARG;
        }

        hr = pp[devIndex]->ActivateObject(__uuidof(IMFMediaSource),
                                          reinterpret_cast<void **>(out.GetAddressOf()));
        // 存 FriendlyName + SymbolicLink（GPU path 也要）
        {
            std::wstring wname = get_mf_string(pp[devIndex], MF_DEVSOURCE_ATTRIBUTE_FRIENDLY_NAME);
            if (!wname.empty())
                dev_name_ = utf8_from_wide(wname.c_str());
            dev_sym_link_w_ = get_mf_string(pp[devIndex], MF_DEVSOURCE_ATTRIBUTE_SOURCE_TYPE_VIDCAP_SYMBOLIC_LINK);
        }

        for (UINT32 i = 0; i < count; ++i)
            pp[i]->Release();
        CoTaskMemFree(pp);
        return hr;
    };

    HRESULT hr = S_OK;

    MDBG("DXGI: Try DXGI+VP - begin", S_OK);
    hr = activate_source(source_);
    if (FAILED(hr))
    {
        MDBG("DXGI: activate_source failed", hr);
        return false;
    }

    ComPtr<IMFAttributes> rdAttr;
    hr = MFCreateAttributes(&rdAttr, 3);
    if (FAILED(hr))
    {
        MDBG("DXGI: MFCreateAttributes(reader) failed", hr);
        return false;
    }

    rdAttr->SetUnknown(MF_SOURCE_READER_D3D_MANAGER, dxgi_mgr_.Get());
    rdAttr->SetUINT32(MF_SOURCE_READER_ENABLE_VIDEO_PROCESSING, TRUE);
    rdAttr->SetUINT32(MF_READWRITE_ENABLE_HARDWARE_TRANSFORMS, TRUE);

    if (!source_)
    {
        MDBG("DXGI: source_ is null before MFCreateSourceReaderFromMediaSource", 0);
        return false;
    }
    if (!dxgi_mgr_)
    {
        MDBG("DXGI: dxgi_mgr_ is null before MFCreateSourceReaderFromMediaSource", 0);
        return false;
    }

    hr = MFCreateSourceReaderFromMediaSource(source_.Get(), rdAttr.Get(), reader_.ReleaseAndGetAddressOf());
    if (FAILED(hr))
    {
        MDBG("DXGI: MFCreateSourceReaderFromMediaSource (with attr) failed", hr);

        // 如果是你現在遇到的 E_INVALIDARG，就改用「重新 activate 一顆新的 source 再建乾淨 reader」的方式重試
        if (hr == E_INVALIDARG)
        {
            MDBG("DXGI: retry MFCreateSourceReaderFromMediaSource with nullptr attr", hr);

            // 先把舊的 reader / source 都清掉，因為舊的 source 很可能已經被 Shutdown
            reader_.Reset();
            source_.Reset();

            // ★ 重新 activate 一顆新的 MediaSource（用同一個 devIndex）
            HRESULT hr2 = activate_source(source_);
            if (FAILED(hr2) || !source_)
            {
                MDBG("DXGI: activate_source (retry) failed", hr2);
                source_.Reset();
                return false; // DXGI 這條就放棄，最後 open() 會走 CPU fallback
            }

            // 用「不帶任何 attributes」建一個最乾淨的 reader
            hr = MFCreateSourceReaderFromMediaSource(
                source_.Get(),
                nullptr,
                reader_.ReleaseAndGetAddressOf());
            if (FAILED(hr))
            {
                MDBG("DXGI: MFCreateSourceReaderFromMediaSource (no attr) also failed", hr);
                reader_.Reset();
                source_.Reset();
                return false;
            }

            MDBG("DXGI: CreateReader(no attr) succeeded, continue DXGI path", hr);
        }
        else
        {
            // 不是 E_INVALIDARG，就當成不支援 DXGI，讓 open() fallback 到 CPU
            reader_.Reset();
            source_.Reset();
            return false;
        }
    }

    // 能走到這裡代表 reader_ 已經成功建立（帶 attr 或無 attr）
    use_dxgi_ = true;
    cpu_path_ = false;
    MDBG("DXGI: DXGI+VP SUCCESS", hr);
    return true;
}

bool WinMFProvider::pick_best_native(GUID &sub, UINT32 &w, UINT32 &h, UINT32 &fn, UINT32 &fd)
{
    struct Cand
    {
        GUID sub;
        UINT32 w, h, fn, fd;
        long long score;
        ComPtr<IMFMediaType> mt;
    };
    std::vector<Cand> list;

    for (DWORD i = 0;; ++i)
    {
        ComPtr<IMFMediaType> t;
        HRESULT hr = reader_->GetNativeMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, i, &t);
        if (FAILED(hr) && hr != MF_E_NO_MORE_TYPES)
        {
            DBG("GetNativeMediaType", hr);
        }
        if (hr == MF_E_NO_MORE_TYPES)
            break;
        if (FAILED(hr) || !t)
            continue;
        GUID major = GUID_NULL, s = GUID_NULL;
        if (FAILED(t->GetGUID(MF_MT_MAJOR_TYPE, &major)) || major != MFMediaType_Video)
            continue;
        if (FAILED(t->GetGUID(MF_MT_SUBTYPE, &s)))
            continue;

        // 收 P010/NV12/Y210/YUY2/MJPG
        if (!(s == MFVideoFormat_P010 || s == MFVideoFormat_NV12 ||
              s == MFVideoFormat_Y210 || s == MFVideoFormat_YUY2 || s == MFVideoFormat_MJPG))
            continue;

        UINT32 cw = 0, ch = 0, fnum = 0, fden = 1;
        if (FAILED(MFGetAttributeSize(t.Get(), MF_MT_FRAME_SIZE, &cw, &ch)))
            continue;
        MFGetAttributeRatio(t.Get(), MF_MT_FRAME_RATE, &fnum, &fden);
        double fps = fden ? (double)fnum / fden : 0.0;

        int pref = (s == MFVideoFormat_P010) ? 4 : (s == MFVideoFormat_Y210) ? 3
                                               : (s == MFVideoFormat_NV12)   ? 2
                                               : (s == MFVideoFormat_YUY2)   ? 1
                                                                             : 0;
        long long score = (long long)cw * ch * 100000 + (long long)(fps * 1000) * 100 + pref;
        list.push_back({s, cw, ch, fnum, fden, score, t});
    }
    if (list.empty())
        return false;

    std::sort(list.begin(), list.end(), [](auto &a, auto &b)
              { return a.score > b.score; });
    const auto &best = list[0];

    // 1) 原生就是 P010/NV12，或在 GPU 路徑下的 Y210 → 直接套用
    if (best.sub == MFVideoFormat_P010 || best.sub == MFVideoFormat_NV12 ||
        (best.sub == MFVideoFormat_Y210 && use_dxgi_))
    {
        HRESULT hr = reader_->SetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, best.mt.Get());
        if (FAILED(hr))
        {
            DBG("SetCurrentMediaType(NV12)", hr);
            return false;
        }

        // Read back actual negotiated type (incl. stride)
        ComPtr<IMFMediaType> cur;
        if (SUCCEEDED(reader_->GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur)) && cur)
        {
            UINT32 rw = 0, rh = 0, rfn = 0, rfd = 1;
            GUID rsub = GUID_NULL;
            MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &rw, &rh);
            MFGetAttributeRatio(cur.Get(), MF_MT_FRAME_RATE, &rfn, &rfd);
            cur->GetGUID(MF_MT_SUBTYPE, &rsub);
            cur_fps_num_ = (int)rfn;
            cur_fps_den_ = (int)rfd;
            cur_stride_ = mf_default_stride_bytes(cur.Get());
            if (cur_stride_ <= 0)
            {
                if (rsub == MFVideoFormat_P010)
                    cur_stride_ = (int)rw * 2;
                else if (rsub == MFVideoFormat_Y210)
                    cur_stride_ = (int)rw * 4;
                else
                    cur_stride_ = (int)rw;
            }

            std::ostringstream oss;
            oss << "[WinMF] pick_best_native: subtype=" << mf_subtype_name(rsub)
                << ", " << rw << "x" << rh
                << " @ " << rfn;
            if (rfd != 1)
                oss << "/" << rfd;
            oss << " fps"
                << ", default_stride=" << cur_stride_ << " bytes";
            emit_error(GCAP_OK, oss.str().c_str());
        }

        sub = best.sub;
        w = best.w;
        h = best.h;
        fn = best.fn;
        fd = best.fd;
        cpu_path_ = !use_dxgi_; // 沒有 DXGI 紋理仍要 CPU
        return true;
    }

    // 2) 否則（YUY2/MJPG）→ 請 reader 直接輸出 ARGB32（CPU 路徑）
    ComPtr<IMFMediaType> req;
    if (FAILED(MFCreateMediaType(&req)))
        return false;
    req->SetGUID(MF_MT_MAJOR_TYPE, MFMediaType_Video);
    req->SetGUID(MF_MT_SUBTYPE, MFVideoFormat_ARGB32);
    MFSetAttributeSize(req.Get(), MF_MT_FRAME_SIZE, best.w, best.h);
    MFSetAttributeRatio(req.Get(), MF_MT_FRAME_RATE, best.fn, best.fd);

    HRESULT hr = reader_->SetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, nullptr, req.Get());
    if (FAILED(hr))
    {
        DBG("SetCurrentMediaType(ARGB32)", hr);
        return false;
    }

    // 讀回實際（保險）
    ComPtr<IMFMediaType> cur;
    if (FAILED(reader_->GetCurrentMediaType(MF_SOURCE_READER_FIRST_VIDEO_STREAM, &cur)))
    {
        DBG("GetCurrentMediaType", E_FAIL);
        return false;
    }

    UINT32 rw = 0, rh = 0, rfn = 0, rfd = 1;
    MFGetAttributeSize(cur.Get(), MF_MT_FRAME_SIZE, &rw, &rh);
    MFGetAttributeRatio(cur.Get(), MF_MT_FRAME_RATE, &rfn, &rfd);

    sub = MFVideoFormat_ARGB32;
    w = rw;
    h = rh;
    fn = rfn;
    fd = rfd;
    cpu_path_ = true; // 明確走 CPU
    return true;
}

// -------------------- Pipeline / Rendering --------------------

static const char *g_vs_src = R"(
struct VSIn  { float2 pos:POSITION; float2 uv:TEXCOORD0; };
struct VSOut { float4 pos:SV_Position; float2 uv:TEXCOORD0; };
VSOut main(VSIn i){
  VSOut o; o.pos=float4(i.pos,0,1); o.uv=i.uv; return o;
}
)";

static const char *g_ps_nv12 = R"(
Texture2D texY   : register(t0);
Texture2D texUV  : register(t1);
SamplerState samL: register(s0);


cbuffer ProcAmp : register(b0)
{
    uint  width;
    uint  height;
    float invW;
    float invH;

    float br;     // brightness offset (normalized, about [-0.5..0.5])
    float ct;     // contrast factor (1.0 = neutral)
    float sat;    // saturation factor (1.0 = neutral)
    float hueSin; // sin(hue)

    float hueCos;   // cos(hue)
    float sharpAmt; // [-1..+1], 0 = neutral
    float pad0;
    float pad1;
};

static float3 apply_rgb_procamp(float3 rgb)
{
    // contrast + brightness
    rgb = (rgb - 0.5) * ct + 0.5 + br;

    // saturation
    float l = dot(rgb, float3(0.299, 0.587, 0.114));
    rgb = lerp(float3(l, l, l), rgb, sat);

    return saturate(rgb);
}

static float2 rotate_uv(float2 uv01)
{
    // uv01 is 0..1, convert to signed around 0
    float2 uv = uv01 - 0.5;
    float u = uv.x;
    float v = uv.y;
    float u2 = u * hueCos - v * hueSin;
    float v2 = u * hueSin + v * hueCos;
    return float2(u2, v2) + 0.5;
}


float3 yuv_to_rgb709(float y, float u, float v)
{
    // y,u,v are normalized 0..1, assume limited->full & BT.709
    y = y * 255.0;
    u = (u - 0.5) * 255.0;
    v = (v - 0.5) * 255.0;
    float c = y - 16.0;
    float d = u;
    float e = v;
    float r = 1.164383 * c + 1.792741 * e;
    float g = 1.164383 * c - 0.213249 * d - 0.532909 * e;
    float b = 1.164383 * c + 2.112402 * d;
    return float3(r,g,b)/255.0;
}

float sampleY(float2 uv)
{
    return texY.Sample(samL, uv).r;
}

float4 main(float4 pos:SV_Position, float2 uv:TEXCOORD0) : SV_Target
{
    // ---- Sharpness on luma (Y) via small unsharp mask ----
    float yC = sampleY(uv);
    float yL = sampleY(uv + float2(-invW, 0));
    float yR = sampleY(uv + float2( invW, 0));
    float yU = sampleY(uv + float2(0, -invH));
    float yD = sampleY(uv + float2(0,  invH));

    float blur = (yC*4.0 + yL + yR + yU + yD) / 8.0;
    float y  = saturate(yC + sharpAmt * (yC - blur));

    float2 uv2 = texUV.Sample(samL, uv).rg;
    uv2 = rotate_uv(uv2);

    float3 rgb = yuv_to_rgb709(y, uv2.x, uv2.y);
    rgb = apply_rgb_procamp(rgb);
    return float4(rgb, 1.0);
}
)";

static const char *g_ps_p010 = R"(
Texture2D<uint>  texY16   : register(t0);
Texture2D<uint2> texUV16  : register(t1);
SamplerState samL: register(s0);


cbuffer ProcAmp : register(b0)
{
    uint  width;
    uint  height;
    float invW;
    float invH;

    float br;     // brightness offset (normalized, about [-0.5..0.5])
    float ct;     // contrast factor (1.0 = neutral)
    float sat;    // saturation factor (1.0 = neutral)
    float hueSin; // sin(hue)

    float hueCos;   // cos(hue)
    float sharpAmt; // [-1..+1], 0 = neutral
    float pad0;
    float pad1;
};

static float3 apply_rgb_procamp(float3 rgb)
{
    // contrast + brightness
    rgb = (rgb - 0.5) * ct + 0.5 + br;

    // saturation
    float l = dot(rgb, float3(0.299, 0.587, 0.114));
    rgb = lerp(float3(l, l, l), rgb, sat);

    return saturate(rgb);
}

static float2 rotate_uv(float2 uv01)
{
    // uv01 is 0..1, convert to signed around 0
    float2 uv = uv01 - 0.5;
    float u = uv.x;
    float v = uv.y;
    float u2 = u * hueCos - v * hueSin;
    float v2 = u * hueSin + v * hueCos;
    return float2(u2, v2) + 0.5;
}


float3 yuv_to_rgb709(float y, float u, float v)
{
    y = y * 255.0;
    u = (u - 0.5) * 255.0;
    v = (v - 0.5) * 255.0;
    float c = y - 16.0;
    float d = u;
    float e = v;
    float r = 1.164383 * c + 1.792741 * e;
    float g = 1.164383 * c - 0.213249 * d - 0.532909 * e;
    float b = 1.164383 * c + 2.112402 * d;
    return float3(r,g,b)/255.0;
}

float loadY(int2 ip)
{
    ip.x = clamp(ip.x, 0, (int)width - 1);
    ip.y = clamp(ip.y, 0, (int)height - 1);
    uint yy = texY16.Load(int3(ip, 0)).r;
    return (float)((yy >> 6) & 1023) / 1023.0;
}

float4 main(float4 pos:SV_Position, float2 uv:TEXCOORD0) : SV_Target
{
    int2 ip = int2(pos.xy);

    // Sharpness on luma
    float yC = loadY(ip);
    float yL = loadY(ip + int2(-1, 0));
    float yR = loadY(ip + int2( 1, 0));
    float yU = loadY(ip + int2( 0,-1));
    float yD = loadY(ip + int2( 0, 1));
    float blur = (yC*4.0 + yL + yR + yU + yD) / 8.0;
    float y = saturate(yC + sharpAmt * (yC - blur));

    uint2 uvv = texUV16.Load(int3(ip, 0)).rg;
    float u = (float)((uvv.x >> 6) & 1023) / 1023.0;
    float v = (float)((uvv.y >> 6) & 1023) / 1023.0;

    float2 uv2 = rotate_uv(float2(u, v));

    float3 rgb = yuv_to_rgb709(y, uv2.x, uv2.y);
    rgb = apply_rgb_procamp(rgb);
    return float4(rgb, 1.0);
}
)";

// YUY2（4:2:2 packed）：
// 我們把每兩個像素打包成一個 RGBA8_UINT texel：
//   R=Y0, G=U, B=Y1, A=V
// texture width = ceil(w/2)
static const char *g_ps_yuy2 = R"(
// YUY2 (4:2:2 packed):
// Each texel packs 2 pixels: R=Y0, G=U, B=Y1, A=V
// texture width = ceil(w/2)
Texture2D<uint4> texP : register(t0);


cbuffer ProcAmp : register(b0)
{
    uint  width;
    uint  height;
    float invW;
    float invH;

    float br;     // brightness offset (normalized, about [-0.5..0.5])
    float ct;     // contrast factor (1.0 = neutral)
    float sat;    // saturation factor (1.0 = neutral)
    float hueSin; // sin(hue)

    float hueCos;   // cos(hue)
    float sharpAmt; // [-1..+1], 0 = neutral
    float pad0;
    float pad1;
};

static float3 apply_rgb_procamp(float3 rgb)
{
    // contrast + brightness
    rgb = (rgb - 0.5) * ct + 0.5 + br;

    // saturation
    float l = dot(rgb, float3(0.299, 0.587, 0.114));
    rgb = lerp(float3(l, l, l), rgb, sat);

    return saturate(rgb);
}

static float2 rotate_uv(float2 uv01)
{
    // uv01 is 0..1, convert to signed around 0
    float2 uv = uv01 - 0.5;
    float u = uv.x;
    float v = uv.y;
    float u2 = u * hueCos - v * hueSin;
    float v2 = u * hueSin + v * hueCos;
    return float2(u2, v2) + 0.5;
}


float3 yuv_to_rgb709(float y, float u, float v)
{
    y = y * 255.0;
    u = (u - 0.5) * 255.0;
    v = (v - 0.5) * 255.0;
    float c = y - 16.0;
    float d = u;
    float e = v;
    float r = 1.164383 * c + 1.792741 * e;
    float g = 1.164383 * c - 0.213249 * d - 0.532909 * e;
    float b = 1.164383 * c + 2.112402 * d;
    return float3(r,g,b)/255.0;
}

float loadY(int x, int y)
{
    x = clamp(x, 0, (int)width - 1);
    y = clamp(y, 0, (int)height - 1);
    uint4 p = texP.Load(int3(x >> 1, y, 0));
    uint yy = ((x & 1) != 0) ? p.b : p.r;
    return (float)yy / 255.0;
}

float2 loadUV01(int x, int y)
{
    x = clamp(x, 0, (int)width - 1);
    y = clamp(y, 0, (int)height - 1);
    uint4 p = texP.Load(int3(x >> 1, y, 0));
    float u = (float)p.g / 255.0;
    float v = (float)p.a / 255.0;
    return float2(u, v);
}

float4 main(float4 pos:SV_Position, float2 uv:TEXCOORD0) : SV_Target
{
    int2 ip = int2(pos.xy);
    int px = ip.x;
    int py = ip.y;

    // Sharpness on luma
    float yC = loadY(px, py);
    float yL = loadY(px - 1, py);
    float yR = loadY(px + 1, py);
    float yU = loadY(px, py - 1);
    float yD = loadY(px, py + 1);
    float blur = (yC*4.0 + yL + yR + yU + yD) / 8.0;
    float y = saturate(yC + sharpAmt * (yC - blur));

    float2 uv01 = loadUV01(px, py);
    uv01 = rotate_uv(uv01);

    float3 rgb = yuv_to_rgb709(y, uv01.x, uv01.y);
    rgb = apply_rgb_procamp(rgb);
    return float4(rgb, 1.0);
}
)";

// NV12 → RGBA 的 Compute Shader 版本

// Y210（4:2:2 packed, 10-bit in 16-bit container）：
// 每個 texel 打包 2 個像素：R=Y0, G=U, B=Y1, A=V
// texture width = ceil(w/2), format = R16G16B16A16_UINT
static const char *g_ps_y210 = R"(
Texture2D<uint4> texP : register(t0);

cbuffer ProcAmp : register(b0)
{
    uint  width;
    uint  height;
    float invW;
    float invH;

    float br;
    float ct;
    float sat;
    float hueSin;

    float hueCos;
    float sharpAmt;
    float pad0;
    float pad1;
};

static float3 apply_rgb_procamp(float3 rgb)
{
    rgb = (rgb - 0.5) * ct + 0.5 + br;
    float l = dot(rgb, float3(0.299, 0.587, 0.114));
    rgb = lerp(float3(l, l, l), rgb, sat);
    return saturate(rgb);
}

static float2 rotate_uv(float2 uv01)
{
    float2 uv = uv01 - 0.5;
    float u = uv.x;
    float v = uv.y;
    float u2 = u * hueCos - v * hueSin;
    float v2 = u * hueSin + v * hueCos;
    return float2(u2, v2) + 0.5;
}

float3 yuv_to_rgb709(float y, float u, float v)
{
    y = y * 255.0;
    u = (u - 0.5) * 255.0;
    v = (v - 0.5) * 255.0;
    float c = y - 16.0;
    float d = u;
    float e = v;
    float r = 1.164383 * c + 1.792741 * e;
    float g = 1.164383 * c - 0.213249 * d - 0.532909 * e;
    float b = 1.164383 * c + 2.112402 * d;
    return float3(r,g,b)/255.0;
}

float loadY(int x, int y)
{
    x = clamp(x, 0, (int)width - 1);
    y = clamp(y, 0, (int)height - 1);
    uint4 p = texP.Load(int3(x >> 1, y, 0));
    uint yy = ((x & 1) != 0) ? p.b : p.r;
    return (float)(yy & 1023) / 1023.0;
}

float2 loadUV01(int x, int y)
{
    x = clamp(x, 0, (int)width - 1);
    y = clamp(y, 0, (int)height - 1);
    uint4 p = texP.Load(int3(x >> 1, y, 0));
    float u = (float)(p.g & 1023) / 1023.0;
    float v = (float)(p.a & 1023) / 1023.0;
    return float2(u, v);
}

float4 main(float4 pos:SV_Position, float2 uv:TEXCOORD0) : SV_Target
{
    int2 ip = int2(pos.xy);
    int px = ip.x;
    int py = ip.y;

    float yC = loadY(px, py);
    float yL = loadY(px - 1, py);
    float yR = loadY(px + 1, py);
    float yU = loadY(px, py - 1);
    float yD = loadY(px, py + 1);
    float blur = (yC*4.0 + yL + yR + yU + yD) / 8.0;
    float y = saturate(yC + sharpAmt * (yC - blur));

    float2 uv01 = loadUV01(px, py);
    uv01 = rotate_uv(uv01);

    float3 rgb = yuv_to_rgb709(y, uv01.x, uv01.y);
    rgb = apply_rgb_procamp(rgb);
    return float4(rgb, 1.0);
}
)";

static const char *g_cs_nv12 = R"(
Texture2D<float>   texY    : register(t0);
Texture2D<float2>  texUV   : register(t1);
RWTexture2D<float4> texOut : register(u0);

cbuffer ProcAmp : register(b0)
{
    uint  width;
    uint  height;
    float invW;
    float invH;

    float br;
    float ct;
    float sat;
    float hueSin;

    float hueCos;
    float sharpAmt;
    float pad0;
    float pad1;
};

static float3 apply_rgb_procamp(float3 rgb)
{
    rgb = (rgb - 0.5) * ct + 0.5 + br;
    float l = dot(rgb, float3(0.299, 0.587, 0.114));
    rgb = lerp(float3(l,l,l), rgb, sat);
    return saturate(rgb);
}

static float2 rotate_uv(float2 uv01)
{
    float2 uv = uv01 - 0.5;
    float u = uv.x;
    float v = uv.y;
    float u2 = u * hueCos - v * hueSin;
    float v2 = u * hueSin + v * hueCos;
    return float2(u2, v2) + 0.5;
}

[numthreads(16, 16, 1)]
void main(uint3 tid : SV_DispatchThreadID)
{
    uint x = tid.x;
    uint y = tid.y;
    if (x >= width || y >= height) return;

    float yC = texY.Load(int3(x, y, 0));
    float yL = texY.Load(int3((int)max((int)x - 1, 0), (int)y, 0));
    float yR = texY.Load(int3((int)min((int)x + 1, (int)width - 1), (int)y, 0));
    float yU = texY.Load(int3((int)x, (int)max((int)y - 1, 0), 0));
    float yD = texY.Load(int3((int)x, (int)min((int)y + 1, (int)height - 1), 0));
    float blur = (yC*4.0 + yL + yR + yU + yD) / 8.0;
    float yNorm = saturate(yC + sharpAmt * (yC - blur));

    float2 uvNorm = texUV.Load(int3(x / 2, y / 2, 0));
    uvNorm = rotate_uv(uvNorm);

    // Convert to RGB (BT.709 limited->full)
    float Y = yNorm * 255.0;
    float U = (uvNorm.x - 0.5) * 255.0;
    float V = (uvNorm.y - 0.5) * 255.0;

    float c = Y - 16.0;
    float d = U;
    float e = V;

    float r = 1.164383 * c + 1.792741 * e;
    float g = 1.164383 * c - 0.213249 * d - 0.532909 * e;
    float b = 1.164383 * c + 2.112402 * d;

    float3 rgb = float3(r, g, b) / 255.0;
    rgb = apply_rgb_procamp(rgb);

    texOut[uint2(x, y)] = float4(rgb, 1.0);
}
)";

static const char *g_ps_fp16_to_rgba8 = R"(
Texture2D<float4> tex0 : register(t0);
SamplerState samL : register(s0);

struct PSIn
{
    float4 pos : SV_Position;
    float2 uv  : TEXCOORD0;
};

float4 main(PSIn i) : SV_Target
{
    float4 c = tex0.Sample(samL, i.uv);
    return saturate(c);
}
)";

static const char *g_ps_fp16_to_preview = R"(
Texture2D<float4> tex0 : register(t0);
SamplerState samL : register(s0);

struct PSIn
{
    float4 pos : SV_Position;
    float2 uv  : TEXCOORD0;
};

float4 main(PSIn i) : SV_Target
{
    float4 c = tex0.Sample(samL, i.uv);
    return float4(saturate(c.rgb), 1.0);
}
)";

static const char *g_ps_composite_overlay_fp16 = R"(
Texture2D<float4> texBase    : register(t0);
Texture2D<float4> texOverlay : register(t1);
SamplerState samL : register(s0);

struct PSIn
{
    float4 pos : SV_Position;
    float2 uv  : TEXCOORD0;
};

float4 main(PSIn i) : SV_Target
{
    float4 base = texBase.Sample(samL, i.uv);
    float4 ov   = texOverlay.Sample(samL, i.uv);
    float a = saturate(ov.a);
    float3 rgb = ov.rgb + base.rgb * (1.0 - a);
    return float4(rgb, 1.0);
}
)";

static const char *g_ps_rgba8_to_preview = R"(
Texture2D<float4> tex0 : register(t0);
SamplerState samL : register(s0);

struct PSIn
{
    float4 pos : SV_Position;
    float2 uv  : TEXCOORD0;
};

float4 main(PSIn i) : SV_Target
{
    float4 c = tex0.Sample(samL, i.uv);
    c.rgb = saturate(c.rgb);
    return c;
}
)";

bool WinMFProvider::create_shaders_and_states()
{
    return pipeline_ && pipeline_->create_shaders_and_states();
}

bool WinMFProvider::ensure_rt_and_pipeline(int w, int h)
{
    return pipeline_ && pipeline_->ensure_rt_and_pipeline(w, h);
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>
WinMFProvider::createSRV_NV12(ID3D11Device *dev, ID3D11Texture2D *tex, bool uv)
{
    using Microsoft::WRL::ComPtr;
    if (!dev || !tex)
        return {};

    D3D11_SHADER_RESOURCE_VIEW_DESC d = {};
    d.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    d.Texture2D.MipLevels = 1;
    d.Format = uv ? DXGI_FORMAT_R8G8_UNORM : DXGI_FORMAT_R8_UNORM;

    ComPtr<ID3D11ShaderResourceView> s;
    if (FAILED(dev->CreateShaderResourceView(tex, &d, &s)))
        return {};
    return s;
}

Microsoft::WRL::ComPtr<ID3D11ShaderResourceView>
WinMFProvider::createSRV_P010(ID3D11Device *dev, ID3D11Texture2D *tex, bool uv)
{
    using Microsoft::WRL::ComPtr;
    if (!dev || !tex)
        return {};

    D3D11_SHADER_RESOURCE_VIEW_DESC d = {};
    d.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    d.Texture2D.MipLevels = 1;
    d.Format = uv ? DXGI_FORMAT_R16G16_UNORM : DXGI_FORMAT_R16_UNORM;

    ComPtr<ID3D11ShaderResourceView> s;
    if (FAILED(dev->CreateShaderResourceView(tex, &d, &s)))
        return {};
    return s;
}

bool WinMFProvider::render_yuv_to_fp16(ID3D11Texture2D *yuvTex)
{
    if (!yuvTex)
        return false;

    // Create plane SRVs
    Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> srvY, srvUV;
    Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> srvP;
    if (cur_subtype_ == MFVideoFormat_NV12)
    {
        srvY = createSRV_NV12(d3d_.Get(), yuvTex, false); // Y
        srvUV = createSRV_NV12(d3d_.Get(), yuvTex, true); // UV
    }
    else if (cur_subtype_ == MFVideoFormat_P010)
    {
        srvY = createSRV_P010(d3d_.Get(), yuvTex, false); // Y
        srvUV = createSRV_P010(d3d_.Get(), yuvTex, true); // UV
    }
    else if (cur_subtype_ == MFVideoFormat_YUY2)
    {
        // YUY2：yuvTex 會是 upload_yuy2_packed_（RGBA8_UINT）
        D3D11_SHADER_RESOURCE_VIEW_DESC sd{};
        sd.Format = DXGI_FORMAT_R8G8B8A8_UINT;
        sd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        sd.Texture2D.MipLevels = 1;
        if (FAILED(d3d_->CreateShaderResourceView(yuvTex, &sd, &srvP)))
            return false;
    }
    else if (cur_subtype_ == MFVideoFormat_Y210)
    {
        // Y210：yuvTex 會是 upload_y210_packed_（R16G16B16A16_UINT）
        D3D11_SHADER_RESOURCE_VIEW_DESC sd{};
        sd.Format = DXGI_FORMAT_R16G16B16A16_UINT;
        sd.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
        sd.Texture2D.MipLevels = 1;
        if (FAILED(d3d_->CreateShaderResourceView(yuvTex, &sd, &srvP)))
            return false;
    }
    else
    {
        return false;
    }

    if (cur_subtype_ == MFVideoFormat_YUY2 || cur_subtype_ == MFVideoFormat_Y210)
    {
        if (!srvP)
            return false;
    }
    else
    {
        if (!srvY || !srvUV)
            return false;
    }

    if (use_compute_nv12_ && cur_subtype_ == MFVideoFormat_NV12)
    {
        return render_nv12_to_rgba_cs(srvY.Get(), srvUV.Get());
    }

    // Set pipeline
    UINT stride = sizeof(float) * 4, offset = 0;
    ID3D11Buffer *pVB = pipeline_->vb_.Get();
    ctx_->IASetVertexBuffers(0, 1, &pVB, &stride, &offset);
    ctx_->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    ctx_->IASetInputLayout(pipeline_->il_.Get());
    ctx_->VSSetShader(pipeline_->vs_.Get(), nullptr, 0);

    ID3D11PixelShader *ps = nullptr;
    if (cur_subtype_ == MFVideoFormat_NV12)
        ps = pipeline_->ps_nv12_.Get();
    else if (cur_subtype_ == MFVideoFormat_P010)
        ps = pipeline_->ps_p010_.Get();
    else if (cur_subtype_ == MFVideoFormat_YUY2)
        ps = pipeline_->ps_yuy2_.Get();
    else if (cur_subtype_ == MFVideoFormat_Y210)
        ps = pipeline_->ps_y210_.Get();
    else
        return false;

    // 更新 ProcAmp constant buffer（width/height + B/C/H/S/Sharp）
    if (pipeline_->cs_params_)
    {
        struct CB
        {
            uint32_t width;
            uint32_t height;
            float invW;
            float invH;
            float brightness;
            float contrast;
            float saturation;
            float hueSin;
            float hueCos;
            float sharpAmount;
            float pad0;
            float pad1;
        } cb;

        cb.width = (uint32_t)cur_w_;
        cb.height = (uint32_t)cur_h_;
        cb.invW = (cur_w_ > 0) ? (1.0f / (float)cur_w_) : 0.0f;
        cb.invH = (cur_h_ > 0) ? (1.0f / (float)cur_h_) : 0.0f;

        cb.brightness = ((float)procamp_.brightness - 128.0f) / 128.0f * 0.5f;
        cb.contrast = (float)procamp_.contrast / 128.0f;
        cb.saturation = (float)procamp_.saturation / 128.0f;

        const float ang = ((float)procamp_.hue - 128.0f) / 128.0f * 3.14159265f;
        cb.hueSin = sinf(ang);
        cb.hueCos = cosf(ang);

        cb.sharpAmount = ((float)procamp_.sharpness - 128.0f) / 128.0f;
        cb.pad0 = cb.pad1 = 0.0f;

        D3D11_MAPPED_SUBRESOURCE mapped{};
        HRESULT hrMap = ctx_->Map(pipeline_->cs_params_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
        if (SUCCEEDED(hrMap))
        {
            memcpy(mapped.pData, &cb, sizeof(cb));
            ctx_->Unmap(pipeline_->cs_params_.Get(), 0);
        }
    }

    // Bind ProcAmp constant buffer to PS(b0)
    if (pipeline_->cs_params_)
    {
        ID3D11Buffer *cb0[1] = {pipeline_->cs_params_.Get()};
        ctx_->PSSetConstantBuffers(0, 1, cb0);
    }

    ctx_->PSSetShader(ps, nullptr, 0);

    if (cur_subtype_ == MFVideoFormat_YUY2 || cur_subtype_ == MFVideoFormat_Y210)
    {
        ID3D11ShaderResourceView *srvs0[1] = {srvP.Get()};
        ctx_->PSSetShaderResources(0, 1, srvs0);
        // 清掉 t1（避免殘留）
        ID3D11ShaderResourceView *null1[1] = {nullptr};
        ctx_->PSSetShaderResources(1, 1, null1);
    }
    else
    {
        ID3D11ShaderResourceView *srvs[2] = {srvY.Get(), srvUV.Get()};
        ctx_->PSSetShaderResources(0, 2, srvs);
    }

    ID3D11SamplerState *ss = pipeline_->samp_.Get();
    ctx_->PSSetSamplers(0, 1, &ss);

    float clear[4] = {0, 0, 0, 1};
    ID3D11RenderTargetView *rtv = pipeline_->rtv_fp16_.Get();
    // 設定 Viewport，否則 Draw 會跑在「沒有 viewport」的狀態下，畫面是 undefined（現在你看到的黑畫面＋D3D11 WARNING）
    D3D11_VIEWPORT vp{};
    vp.TopLeftX = 0.0f;
    vp.TopLeftY = 0.0f;
    vp.Width = static_cast<FLOAT>(cur_w_);
    vp.Height = static_cast<FLOAT>(cur_h_);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    ctx_->RSSetViewports(1, &vp);
    ctx_->OMSetRenderTargets(1, &rtv, nullptr);
    ctx_->ClearRenderTargetView(rtv, clear);
    ctx_->Draw(6, 0);

    // unbind SRVs (avoid hazard)
    if (cur_subtype_ == MFVideoFormat_YUY2 || cur_subtype_ == MFVideoFormat_Y210)
    {
        ID3D11ShaderResourceView *null0[1] = {nullptr};
        ctx_->PSSetShaderResources(0, 1, null0);
    }
    else
    {
        ID3D11ShaderResourceView *nulls[2] = {nullptr, nullptr};
        ctx_->PSSetShaderResources(0, 2, nulls);
    }

    return true;
}

bool WinMFProvider::composite_overlay_to_scene_fp16()
{
    return pipeline_ && pipeline_->composite_overlay_to_scene_fp16(cur_w_, cur_h_);
}


bool WinMFProvider::blit_fp16_to_rgba8()
{
    return pipeline_ && pipeline_->blit_fp16_to_rgba8(cur_w_, cur_h_);
}


bool WinMFProvider::gpu_overlay_text(const wchar_t *text)
{
    return pipeline_ && pipeline_->gpu_overlay_text(text, cur_w_, cur_h_);
}


// -------------------- Capture loop --------------------

void WinMFProvider::loop()
{
    // Log stride/buffer length diagnostics only once per run (avoid spamming).
    bool logged_layout = false;
    bool logged_len_mismatch = false;

    while (running_)
    {
        DWORD stream = 0, flags = 0;
        LONGLONG ts = 0;
        ComPtr<IMFSample> sample;
        HRESULT hr = reader_->ReadSample(MF_SOURCE_READER_FIRST_VIDEO_STREAM, 0, &stream, &flags, &ts, &sample);
        if (FAILED(hr))
        {
            emit_error(GCAP_EIO, "ReadSample failed");
            break;
        }
        if (!sample)
            continue;

        if (cpu_path_)
        {
            ComPtr<IMFMediaBuffer> buf;
            if (FAILED(sample->ConvertToContiguousBuffer(&buf)))
                continue;

            BYTE *pData = nullptr;
            DWORD maxLen = 0, curLen = 0;
            if (FAILED(buf->Lock(&pData, &maxLen, &curLen)))
                continue;

            // (1) log negotiated stride vs code assumption
            if (!logged_layout)
            {
                std::ostringstream oss;
                oss << "[WinMF] buffer layout (CPU): subtype=" << mf_subtype_name(cur_subtype_)
                    << ", curLen=" << curLen << ", maxLen=" << maxLen
                    << ", negotiated_stride=" << cur_stride_ << " bytes"
                    << ", code_assumes_stride=";
                if (cur_subtype_ == MFVideoFormat_P010)
                    oss << (cur_w_ * 2);
                else if (cur_subtype_ == MFVideoFormat_ARGB32)
                    oss << (cur_w_ * 4);
                else
                    oss << cur_w_;
                oss << " bytes";
                emit_error(GCAP_OK, oss.str().c_str());
                logged_layout = true;
            }

            // (2) bufferLen vs expectedLen
            if (!logged_len_mismatch)
            {
                const int stride = (cur_stride_ > 0) ? cur_stride_ : (cur_subtype_ == MFVideoFormat_P010) ? (cur_w_ * 2)
                                                                 : (cur_subtype_ == MFVideoFormat_ARGB32) ? (cur_w_ * 4)
                                                                                                          : cur_w_;
                size_t expected = 0;
                if (cur_subtype_ == MFVideoFormat_NV12)
                    expected = (size_t)stride * (size_t)cur_h_ + (size_t)stride * (size_t)(cur_h_ / 2);
                else if (cur_subtype_ == MFVideoFormat_P010)
                    expected = (size_t)stride * (size_t)cur_h_ + (size_t)stride * (size_t)(cur_h_ / 2);
                else if (cur_subtype_ == MFVideoFormat_ARGB32)
                    expected = (size_t)stride * (size_t)cur_h_;

                if (expected != 0 && (size_t)curLen < expected)
                {
                    std::ostringstream oss;
                    oss << "[WinMF] WARNING: bufferLen < expected (CPU): curLen=" << curLen
                        << ", expected>=" << expected
                        << ", subtype=" << mf_subtype_name(cur_subtype_)
                        << ", w=" << cur_w_ << ", h=" << cur_h_
                        << ", default_stride=" << stride;
                    emit_error(GCAP_OK, oss.str().c_str());
                    logged_len_mismatch = true;
                }
            }

            gcap_frame_t f{};
            f.width = cur_w_;
            f.height = cur_h_;
            f.pts_ns = (uint64_t)ts * 100;
            f.frame_id = ++frame_id_;

            if (cur_subtype_ == MFVideoFormat_ARGB32)
            {
                f.format = GCAP_FMT_ARGB;
                f.data[0] = pData;
                f.stride[0] = cur_w_ * 4;
                f.plane_count = 1;
                emit_frame_packet_cb(pcb_, user_, GCAP_BACKEND_WINMF_CPU, GCAP_SOURCE_WINMF_CPU, 0, f);
                if (vcb_)
                    vcb_(&f, user_);
            }
            else if (cur_subtype_ == MFVideoFormat_NV12)
            {
                // NV12: Y 面在前，UV 在後
                const int yStride = (cur_stride_ > 0) ? cur_stride_ : cur_w_;
                const int uvStride = yStride;
                const uint8_t *y = pData;
                const uint8_t *uv = pData + yStride * cur_h_;

                // --- Recording: NV12 直接送進 Sink Writer (H.264) ---
                {
                    std::lock_guard<std::mutex> lock(recorderMutex_);
                    if (recorder_)
                    {
                        recorder_->writeNV12(y, uv,
                                             static_cast<UINT32>(yStride),
                                             static_cast<UINT32>(uvStride),
                                             ts);
                    }
                }

                const size_t needed = (size_t)cur_w_ * (size_t)cur_h_ * 4;
                if (cpu_argb_.size() < needed)
                    cpu_argb_.resize(needed);

                // CPU conversion path supports ProcAmp (Brightness/Contrast/Hue/Saturation/Sharpness)
                gcap::ProcAmpParams pp;
                pp.brightness = procamp_.brightness;
                pp.contrast = procamp_.contrast;
                pp.hue = procamp_.hue;
                pp.saturation = procamp_.saturation;
                pp.sharpness = procamp_.sharpness;

                gcap::nv12_to_argb(y, uv, cur_w_, cur_h_, yStride, uvStride,
                                   cpu_argb_.data(), cur_w_ * 4, pp);

                f.format = GCAP_FMT_ARGB;
                f.data[0] = cpu_argb_.data();
                f.stride[0] = cur_w_ * 4;
                f.plane_count = 1;
                emit_frame_packet_cb(pcb_, user_, GCAP_BACKEND_WINMF_CPU, GCAP_SOURCE_WINMF_CPU, 0, f);
                if (vcb_)
                    vcb_(&f, user_);
            }
            else if (cur_subtype_ == MFVideoFormat_YUY2)
            {
                const int yuy2Stride = (cur_stride_ > 0) ? cur_stride_ : (cur_w_ * 2);
                const uint8_t *yuy2 = pData;

                const size_t needed = (size_t)cur_w_ * (size_t)cur_h_ * 4;
                if (cpu_argb_.size() < needed)
                    cpu_argb_.resize(needed);

                gcap::ProcAmpParams pp;
                pp.brightness = procamp_.brightness;
                pp.contrast = procamp_.contrast;
                pp.hue = procamp_.hue;
                pp.saturation = procamp_.saturation;
                pp.sharpness = procamp_.sharpness;

                gcap::yuy2_to_argb(yuy2, cur_w_, cur_h_, yuy2Stride,
                                   cpu_argb_.data(), cur_w_ * 4, pp);

                f.format = GCAP_FMT_ARGB;
                f.data[0] = cpu_argb_.data();
                f.stride[0] = cur_w_ * 4;
                f.plane_count = 1;
                emit_frame_packet_cb(pcb_, user_, GCAP_BACKEND_WINMF_CPU, GCAP_SOURCE_WINMF_CPU, 0, f);
                if (vcb_)
                    vcb_(&f, user_);
            }
            // 其他（例如 MJPG）理論上 VP 會幫我們解到 NV12/ARGB 之一；萬一還是 MJPG，可再加一個軟解（先不做）

            buf->Unlock();
            continue;
        }

        // 每一筆 sample 都會有 ts (100ns 單位)；我們前面用 f.pts_ns = ts * 100
        double fps_now = 0.0;
        if (last_pts_ns_ != 0)
        {
            uint64_t delta = ((uint64_t)ts * 100) - last_pts_ns_; // ns
            if (delta > 0)
                fps_now = 1e9 / (double)delta;
        }
        // 簡單一階濾波
        if (fps_now > 0.0)
        {
            if (fps_avg_ <= 0.0)
                fps_avg_ = fps_now;
            else
                fps_avg_ = fps_avg_ * 0.9 + fps_now * 0.1;
        }

        last_pts_ns_ = (uint64_t)ts * 100;

        ComPtr<IMFMediaBuffer> buf;
        if (FAILED(sample->ConvertToContiguousBuffer(&buf)))
            continue;

        // --- 嘗試：優先吃 IMFDXGIBuffer；沒有就自己 Upload ---
        ComPtr<IMFDXGIBuffer> dxgibuf;
        HRESULT hrDX = buf.As(&dxgibuf);

        ComPtr<ID3D11Texture2D> yuvTex;

        if (SUCCEEDED(hrDX) && dxgibuf)
        {
            // 裝置真的有 DXGI surface → 直接拿 GPU texture
            UINT subres = 0;
            if (FAILED(dxgibuf->GetResource(IID_PPV_ARGS(&yuvTex))))
            {
                MDBG("DXGI: GetResource from IMFDXGIBuffer failed", E_FAIL);
                continue;
            }
            dxgibuf->GetSubresourceIndex(&subres);
        }
        else
        {
            // ★ 沒有 IMFDXGIBuffer：從 CPU NV12/P010 buffer Upload 到 D3D11 texture，再走 shader
            BYTE *pData = nullptr;
            DWORD maxLen = 0, curLen = 0;

            // 作法 A：優先走 IMF2DBuffer，拿到「真正的 pitch」
            ComPtr<IMF2DBuffer> buf2d;
            LONG srcPitchLong = 0;
            bool locked2d = false;

            HRESULT hr2d = buf.As(&buf2d);
            if (SUCCEEDED(hr2d) && buf2d)
            {
                hr2d = buf2d->Lock2D(&pData, &srcPitchLong);
                if (SUCCEEDED(hr2d) && pData)
                {
                    locked2d = true;
                    // Lock2D 可能回傳負 pitch（top-down/bottom-up），這裡統一用絕對值當 stride
                    if (srcPitchLong < 0)
                        srcPitchLong = -srcPitchLong;
                    // curLen/maxLen 對 2D buffer 不一定可靠；保留 0 也沒關係（後面不再依賴它做 offset）
                }
            }

            if (!locked2d)
            {
                if (FAILED(buf->Lock(&pData, &maxLen, &curLen)) || !pData)
                    continue;
            }

            // (GPU upload fallback) log stride/bufferLen once
            if (!logged_layout)
            {
                std::ostringstream oss;
                oss << "[WinMF] buffer layout (GPU-upload fallback): subtype=" << mf_subtype_name(cur_subtype_)
                    << ", curLen=" << curLen << ", maxLen=" << maxLen
                    << ", negotiated_stride=" << cur_stride_ << " bytes"
                    << ", code_assumes_stride=";
                if (cur_subtype_ == MFVideoFormat_P010)
                    oss << (cur_w_ * 2);
                else
                    oss << cur_w_;
                oss << " bytes";
                emit_error(GCAP_OK, oss.str().c_str());
                logged_layout = true;
            }

            if (!ensure_upload_yuv(cur_w_, cur_h_))
            {
                if (locked2d)
                    buf2d->Unlock2D();
                else
                    buf->Unlock();
                continue;
            }

            D3D11_MAPPED_SUBRESOURCE mapped{};
            HRESULT hrMap = ctx_->Map(upload_yuv_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
            if (FAILED(hrMap))
            {
                if (locked2d)
                    buf2d->Unlock2D();
                else
                    buf->Unlock();
                MDBG("DXGI: Map(upload_yuv_) failed", hrMap);
                continue;
            }

            // bufferLen vs expected (upload path) + RowPitch
            if (!logged_len_mismatch)
            {
                const int assumeStride =
                    (locked2d && srcPitchLong > 0) ? (int)srcPitchLong : (cur_stride_ > 0)                  ? cur_stride_
                                                                     : (cur_subtype_ == MFVideoFormat_P010) ? (cur_w_ * 2)
                                                                                                            : cur_w_;

                const size_t expected = (size_t)assumeStride * (size_t)cur_h_ +
                                        (size_t)assumeStride * (size_t)(cur_h_ / 2);

                // 如果 curLen=0（常見於 2D buffer），就略過這個檢查
                if (curLen != 0 && (size_t)curLen < expected)
                {
                    std::ostringstream oss;
                    oss << "[WinMF] WARNING: bufferLen < expected (upload): curLen=" << curLen
                        << ", expected>=" << expected
                        << ", subtype=" << mf_subtype_name(cur_subtype_)
                        << ", w=" << cur_w_ << ", h=" << cur_h_
                        << ", default_stride=" << assumeStride
                        << ", upload_RowPitch=" << mapped.RowPitch;
                    emit_error(GCAP_OK, oss.str().c_str());
                    logged_len_mismatch = true;
                }
            }

            int w = cur_w_;
            int h = cur_h_;

            if (cur_subtype_ == MFVideoFormat_NV12)
            {
                const int srcStride = (locked2d && srcPitchLong > 0) ? (int)srcPitchLong : (cur_stride_ > 0) ? cur_stride_
                                                                                                             : w;
                const size_t rowBytes = (size_t)w; // NV12 Y/UV 每列 bytes = w

                const uint8_t *srcY = pData;
                const uint8_t *srcUV = pData + (size_t)srcStride * (size_t)h;

                // --- Recording: NV12 直接送進 Sink Writer (H.264) ---
                {
                    std::lock_guard<std::mutex> lock(recorderMutex_);
                    if (recorder_)
                    {
                        recorder_->writeNV12(srcY, srcUV,
                                             static_cast<UINT32>(srcStride),
                                             static_cast<UINT32>(srcStride),
                                             ts);
                    }
                }

                uint8_t *dst = static_cast<uint8_t *>(mapped.pData);

                // Y plane
                for (int y = 0; y < h; ++y)
                    memcpy(dst + mapped.RowPitch * y,
                           srcY + (size_t)srcStride * y,
                           rowBytes);
                // UV plane (h/2 行，pitch 相同)
                for (int y = 0; y < h / 2; ++y)
                    memcpy(dst + mapped.RowPitch * (h + y),
                           srcUV + (size_t)srcStride * y,
                           rowBytes);
            }
            else if (cur_subtype_ == MFVideoFormat_P010)
            {
                // P010: 10-bit，2 bytes per sample
                const int srcStride = (locked2d && srcPitchLong > 0) ? (int)srcPitchLong : (cur_stride_ > 0) ? cur_stride_
                                                                                                             : (w * 2);
                const size_t rowBytes = (size_t)w * 2;

                const uint8_t *srcY = pData;
                const uint8_t *srcUV = pData + (size_t)srcStride * (size_t)h;
                // --- Recording: P010 直接送進 Sink Writer (HEVC) ---
                {
                    std::lock_guard<std::mutex> lock(recorderMutex_);
                    if (recorder_)
                    {
                        recorder_->writeP010(srcY, srcUV,
                                             static_cast<UINT32>(srcStride),
                                             static_cast<UINT32>(srcStride),
                                             ts);
                    }
                }

                uint8_t *dst = static_cast<uint8_t *>(mapped.pData);

                for (int y = 0; y < h; ++y)
                    memcpy(dst + mapped.RowPitch * y,
                           srcY + (size_t)srcStride * y,
                           rowBytes);
                for (int y = 0; y < h / 2; ++y)
                    memcpy(dst + mapped.RowPitch * (h + y),
                           srcUV + (size_t)srcStride * y,
                           rowBytes);
            }
            else if (cur_subtype_ == MFVideoFormat_YUY2)
            {
                const int srcStride = (locked2d && srcPitchLong > 0) ? (int)srcPitchLong
                                                                     : (cur_stride_ > 0 ? cur_stride_ : (w * 2));
                const size_t rowBytes = (size_t)w * 2; // YUY2 每像素 2 bytes

                // 這裡的 upload texture 是「packed」：width = ceil(w/2)，RGBA8_UINT
                if (!ensure_upload_yuv(w, h))
                {
                    if (locked2d)
                        buf2d->Unlock2D();
                    else
                        buf->Unlock();
                    continue;
                }

                D3D11_MAPPED_SUBRESOURCE mapped{};
                HRESULT hrMap = ctx_->Map(upload_yuy2_packed_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
                if (FAILED(hrMap))
                {
                    MDBG("DXGI: Map(upload_yuy2_packed_) failed", hrMap);
                    if (locked2d)
                        buf2d->Unlock2D();
                    else
                        buf->Unlock();
                    continue;
                }

                uint8_t *dst = (uint8_t *)mapped.pData;
                const int w2 = (w + 1) / 2;
                for (int yy = 0; yy < h; ++yy)
                {
                    const uint8_t *srcRow = pData + (size_t)srcStride * (size_t)yy;
                    uint8_t *dstRow = dst + (size_t)mapped.RowPitch * (size_t)yy;

                    // 每 4 bytes（Y0 U Y1 V）→ 寫成 1 個 RGBA8_UINT texel
                    for (int x = 0; x < w2; ++x)
                    {
                        const int srcX = x * 4;
                        // 注意：若 w 是奇數，最後一組的 Y1 可能不存在，這裡用 Y0 補
                        uint8_t Y0 = srcRow[srcX + 0];
                        uint8_t U = srcRow[srcX + 1];
                        uint8_t Y1 = (srcX + 2 < (int)rowBytes) ? srcRow[srcX + 2] : Y0;
                        uint8_t V = (srcX + 3 < (int)rowBytes) ? srcRow[srcX + 3] : srcRow[srcX + 1];

                        uint8_t *d4 = dstRow + x * 4;
                        d4[0] = Y0;
                        d4[1] = U;
                        d4[2] = Y1;
                        d4[3] = V;
                    }
                }

                ctx_->Unmap(upload_yuy2_packed_.Get(), 0);
                if (locked2d)
                    buf2d->Unlock2D();
                else
                    buf->Unlock();

                yuvTex = upload_yuy2_packed_.Get();
            }
            else if (cur_subtype_ == MFVideoFormat_Y210)
            {
                const int srcStride = (locked2d && srcPitchLong > 0) ? (int)srcPitchLong
                                                                     : (cur_stride_ > 0 ? cur_stride_ : (w * 4));
                const size_t rowBytes = (size_t)w * 4; // Y210 每像素 4 bytes（16-bit container）

                if (!ensure_upload_yuv(w, h))
                {
                    if (locked2d)
                        buf2d->Unlock2D();
                    else
                        buf->Unlock();
                    continue;
                }

                D3D11_MAPPED_SUBRESOURCE mapped{};
                HRESULT hrMap = ctx_->Map(upload_y210_packed_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
                if (FAILED(hrMap))
                {
                    MDBG("DXGI: Map(upload_y210_packed_) failed", hrMap);
                    if (locked2d)
                        buf2d->Unlock2D();
                    else
                        buf->Unlock();
                    continue;
                }

                uint8_t *dst = (uint8_t *)mapped.pData;
                const int w2 = (w + 1) / 2;
                for (int yy = 0; yy < h; ++yy)
                {
                    const uint8_t *srcRow = pData + (size_t)srcStride * (size_t)yy;
                    uint8_t *dstRow = dst + (size_t)mapped.RowPitch * (size_t)yy;
                    const uint16_t *src16 = reinterpret_cast<const uint16_t *>(srcRow);
                    uint16_t *dst16 = reinterpret_cast<uint16_t *>(dstRow);
                    const int rowWords = (int)(rowBytes / 2);

                    // 每 4 個 uint16（Y0 U Y1 V）→ 寫成 1 個 R16G16B16A16_UINT texel
                    for (int x = 0; x < w2; ++x)
                    {
                        const int srcX = x * 4;
                        const uint16_t Y0 = src16[srcX + 0];
                        const uint16_t U = src16[srcX + 1];
                        const uint16_t Y1 = (srcX + 2 < rowWords) ? src16[srcX + 2] : Y0;
                        const uint16_t V = (srcX + 3 < rowWords) ? src16[srcX + 3] : U;

                        uint16_t *d4 = dst16 + x * 4;
                        d4[0] = Y0;
                        d4[1] = U;
                        d4[2] = Y1;
                        d4[3] = V;
                    }
                }

                ctx_->Unmap(upload_y210_packed_.Get(), 0);
                if (locked2d)
                    buf2d->Unlock2D();
                else
                    buf->Unlock();

                yuvTex = upload_y210_packed_.Get();
            }

            if (cur_subtype_ == MFVideoFormat_NV12 || cur_subtype_ == MFVideoFormat_P010)
            {
                ctx_->Unmap(upload_yuv_.Get(), 0);
                if (locked2d)
                    buf2d->Unlock2D();
                else
                    buf->Unlock();

                yuvTex = upload_yuv_.Get();
            }
        }

        if (!yuvTex)
            continue;

        if (!render_yuv_to_fp16(yuvTex.Get()))
        {
            MDBG("DXGI: render_yuv_to_fp16 failed", E_FAIL);
            continue;
        }

        // OBS-style overlay path:
        //   1) D2D draws into a transparent BGRA overlay texture
        //   2) shader composites overlay texture into FP16 scene target
        //   3) final scene is blitted to RGBA8 only for CPU readback / compatibility

        // GPU overlay
        wchar_t wdev[256] = L"";
        if (!dev_name_.empty())
        {
            // 簡單從 UTF-8 轉 wchar_t 只為顯示（寬鬆作法）
            int wn = MultiByteToWideChar(CP_UTF8, 0, dev_name_.c_str(), -1, nullptr, 0);
            if (wn > 1 && wn <= 256)
            {
                MultiByteToWideChar(CP_UTF8, 0, dev_name_.c_str(), -1, wdev, 256);
            }
        }

        // refresh_signal_probe(false);

        const GUID osdSubtype = signal_valid_ ? signal_subtype_ : cur_subtype_;
        const int osdW = signal_valid_ ? signal_w_ : cur_w_;
        const int osdH = signal_valid_ ? signal_h_ : cur_h_;

        const wchar_t *fmtName =
            (osdSubtype == MFVideoFormat_P010)     ? L"P010"
            : (osdSubtype == MFVideoFormat_NV12)   ? L"NV12"
            : (osdSubtype == MFVideoFormat_YUY2)   ? L"YUY2"
            : (osdSubtype == MFVideoFormat_Y210)   ? L"Y210"
            : (osdSubtype == MFVideoFormat_ARGB32) ? L"ARGB32"
                                                   : L"?";

        const wchar_t *bitDepth =
            (osdSubtype == MFVideoFormat_P010 || osdSubtype == MFVideoFormat_Y210) ? L"10-bit"
                                                                                   : L"8-bit";

        double fps_show = 0.0;
        if (signal_valid_ && signal_fps_num_ > 0 && signal_fps_den_ > 0)
            fps_show = (double)signal_fps_num_ / (double)signal_fps_den_;
        else if (fps_avg_ > 0.0)
            fps_show = fps_avg_;

        const wchar_t *gpuName =
            (!gpu_name_w_.empty() ? gpu_name_w_.c_str() : L"(GPU: unknown)");

        wchar_t line[512];
        swprintf(line,
                 512,
                 L"%s | GPU: %s | Signal: %dx%d @ %.2f fps | %s %s | #%llu",
                 (wdev[0] ? wdev : L"Device"),
                 gpuName,
                 osdW,
                 osdH,
                 fps_show,
                 fmtName,
                 bitDepth,
                 (unsigned long long)frame_id_);
        if (pipeline_->overlay_rtv_)
        {
            const float clearOverlay[4] = {0, 0, 0, 0};
            ctx_->ClearRenderTargetView(pipeline_->overlay_rtv_.Get(), clearOverlay);
        }

        gpu_overlay_text(line);

        if (!composite_overlay_to_scene_fp16())
        {
            MDBG("DXGI: composite_overlay_to_scene_fp16 failed", E_FAIL);
            continue;
        }

        if (!blit_fp16_to_rgba8())
        {
            MDBG("DXGI: blit_fp16_to_rgba8 failed", E_FAIL);
            continue;
        }

        if (pipeline_->preview_enabled_)
        {
            if (ensure_preview_swapchain(cur_w_, cur_h_))
            {
                present_preview();
            }
        }

        // Readback -> staging -> map
        gcap_frame_t f{};
        const uint64_t outFrameId = ++frame_id_;
        if (pipeline_ && pipeline_->readback_to_frame(cur_w_, cur_h_, (uint64_t)ts * 100, outFrameId, &f))
        {
            emit_frame_packet_cb(pcb_, user_, GCAP_BACKEND_WINMF_GPU, GCAP_SOURCE_WINMF_GPU, 1, f);
            if (vcb_)
                vcb_(&f, user_);
            ctx_->Unmap(pipeline_->rt_stage_.Get(), 0);
        }
    }
}

bool WinMFProvider::ensure_upload_yuv(int w, int h)
{
    if (!d3d_)
        return false;

    if (cur_subtype_ == MFVideoFormat_YUY2)
    {
        return ensure_upload_yuy2_packed(w, h);
    }
    if (cur_subtype_ == MFVideoFormat_Y210)
    {
        return ensure_upload_y210_packed(w, h);
    }

    if (upload_yuv_)
    {
        D3D11_TEXTURE2D_DESC desc{};
        upload_yuv_->GetDesc(&desc);
        if ((int)desc.Width == w && (int)desc.Height == h)
            return true; // 尺寸相同就重複使用
        upload_yuv_.Reset();
    }

    D3D11_TEXTURE2D_DESC td{};
    td.Width = w;
    td.Height = h;
    td.MipLevels = 1;
    td.ArraySize = 1;
    td.SampleDesc.Count = 1;
    td.Format = (cur_subtype_ == MFVideoFormat_P010) ? DXGI_FORMAT_P010 : DXGI_FORMAT_NV12;
    td.Usage = D3D11_USAGE_DYNAMIC;             // 可 CPU 寫入
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;  // 給 pixel shader 當 SRV 用
    td.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE; // CPU write
    td.MiscFlags = 0;

    HRESULT hr = d3d_->CreateTexture2D(&td, nullptr, &upload_yuv_);
    if (FAILED(hr))
    {
        MDBG("DXGI: Create upload NV12 texture failed", hr);
        return false;
    }
    return true;
}

bool WinMFProvider::ensure_upload_yuy2_packed(int w, int h)
{
    if (!d3d_)
        return false;

    const int w2 = (w + 1) / 2;
    if (upload_yuy2_packed_)
    {
        D3D11_TEXTURE2D_DESC desc{};
        upload_yuy2_packed_->GetDesc(&desc);
        if ((int)desc.Width == w2 && (int)desc.Height == h && desc.Format == DXGI_FORMAT_R8G8B8A8_UINT)
            return true;
        upload_yuy2_packed_.Reset();
    }

    D3D11_TEXTURE2D_DESC td{};
    td.Width = (UINT)w2;
    td.Height = (UINT)h;
    td.MipLevels = 1;
    td.ArraySize = 1;
    td.SampleDesc.Count = 1;
    td.Format = DXGI_FORMAT_R8G8B8A8_UINT; // 給 Texture2D<uint4>.Load 用
    td.Usage = D3D11_USAGE_DYNAMIC;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    td.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    td.MiscFlags = 0;

    HRESULT hr = d3d_->CreateTexture2D(&td, nullptr, &upload_yuy2_packed_);
    if (FAILED(hr))
    {
        MDBG("DXGI: Create upload YUY2 packed texture failed", hr);
        return false;
    }
    return true;
}

// 建立/快取 Compute Shader 與 constant buffer
bool WinMFProvider::ensure_upload_y210_packed(int w, int h)
{
    if (!d3d_)
        return false;

    const int w2 = (w + 1) / 2;
    if (upload_y210_packed_)
    {
        D3D11_TEXTURE2D_DESC desc{};
        upload_y210_packed_->GetDesc(&desc);
        if ((int)desc.Width == w2 && (int)desc.Height == h && desc.Format == DXGI_FORMAT_R16G16B16A16_UINT)
            return true;
        upload_y210_packed_.Reset();
    }

    D3D11_TEXTURE2D_DESC td{};
    td.Width = (UINT)w2;
    td.Height = (UINT)h;
    td.MipLevels = 1;
    td.ArraySize = 1;
    td.SampleDesc.Count = 1;
    td.Format = DXGI_FORMAT_R16G16B16A16_UINT; // 給 Texture2D<uint4>.Load 用
    td.Usage = D3D11_USAGE_DYNAMIC;
    td.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    td.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    td.MiscFlags = 0;

    HRESULT hr = d3d_->CreateTexture2D(&td, nullptr, &upload_y210_packed_);
    if (FAILED(hr))
    {
        MDBG("DXGI: Create upload Y210 packed texture failed", hr);
        return false;
    }
    return true;
}

bool WinMFProvider::ensure_compute_shader()
{
    if (cs_nv12_)
        return true;
    if (!d3d_)
        return false;

    ComPtr<ID3DBlob> csb;
    ComPtr<ID3DBlob> err;

    HRESULT hr = D3DCompile(
        g_cs_nv12,
        strlen(g_cs_nv12),
        nullptr,
        nullptr,
        nullptr,
        "main",
        "cs_5_0",
        0,
        0,
        &csb,
        &err);
    if (FAILED(hr))
    {
        if (err)
            OutputDebugStringA((const char *)err->GetBufferPointer());
        MDBG("DXGI: D3DCompile(g_cs_nv12) failed", hr);
        return false;
    }

    hr = d3d_->CreateComputeShader(
        csb->GetBufferPointer(),
        csb->GetBufferSize(),
        nullptr,
        &cs_nv12_);
    if (FAILED(hr))
    {
        MDBG("DXGI: CreateComputeShader(cs_nv12_) failed", hr);
        return false;
    }

    // ProcAmp constant buffer is created in create_shaders_and_states().
    // Keep a fallback here just in case.
    if (!pipeline_->cs_params_)
    {
        D3D11_BUFFER_DESC bd{};
        bd.ByteWidth = 64; // 48 bytes used, round up to 64
        bd.Usage = D3D11_USAGE_DYNAMIC;
        bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
        bd.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

        hr = d3d_->CreateBuffer(&bd, nullptr, &pipeline_->cs_params_);
        if (FAILED(hr))
        {
            MDBG("DXGI: CreateBuffer(pipeline_->cs_params_) failed", hr);
            return false;
        }
    }

    return true;
}

// 用 Compute Shader 把 NV12 轉成 pipeline_->rt_fp16_（RGBA16F）
bool WinMFProvider::render_nv12_to_rgba_cs(ID3D11ShaderResourceView *srvY,
                                           ID3D11ShaderResourceView *srvUV)
{
    if (!srvY || !srvUV || !pipeline_->rt_fp16_ || !ctx_)
        return false;
    if (!ensure_compute_shader())
        return false;

    // 建立/快取 pipeline_->rt_fp16_ 對應的 UAV
    if (!pipeline_->rt_uav_)
    {
        // 讓 D3D 依 pipeline_->rt_fp16_ 原本格式建立 typed UAV（R16G16B16A16_FLOAT）
        HRESULT hr = d3d_->CreateUnorderedAccessView(pipeline_->rt_fp16_.Get(), nullptr, &pipeline_->rt_uav_);
        if (FAILED(hr))
        {
            MDBG("DXGI: CreateUnorderedAccessView(pipeline_->rt_fp16_) failed", hr);
            return false;
        }
    }

    // 更新 ProcAmp constant buffer（width/height + B/C/H/S/Sharp）
    struct ProcAmpCB
    {
        uint32_t width;
        uint32_t height;
        float invW;
        float invH;
        float brightness; // [-0.5, +0.5] in RGB domain
        float contrast;   // [0..2]
        float saturation; // [0..2]
        float hueSin;
        float hueCos;
        float sharpAmount; // [-1..+1]
        float pad0;
        float pad1;
    };

    const float invW = (cur_w_ > 0) ? (1.0f / float(cur_w_)) : 0.0f;
    const float invH = (cur_h_ > 0) ? (1.0f / float(cur_h_)) : 0.0f;
    const float br = (float(procamp_.brightness) - 128.0f) / 128.0f * 0.5f;
    const float ct = float(procamp_.contrast) / 128.0f;
    const float sat = float(procamp_.saturation) / 128.0f;
    const float ang = (float(procamp_.hue) - 128.0f) / 128.0f * 3.1415926535f;
    const float hs = sinf(ang);
    const float hc = cosf(ang);
    const float sh = (float(procamp_.sharpness) - 128.0f) / 128.0f; // -1..+1

    ProcAmpCB cb{};
    cb.width = static_cast<uint32_t>(cur_w_);
    cb.height = static_cast<uint32_t>(cur_h_);
    cb.invW = invW;
    cb.invH = invH;
    cb.brightness = br;
    cb.contrast = ct;
    cb.saturation = sat;
    cb.hueSin = hs;
    cb.hueCos = hc;
    cb.sharpAmount = sh;

    D3D11_MAPPED_SUBRESOURCE mapped{};
    HRESULT hrMap = ctx_->Map(pipeline_->cs_params_.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
    if (FAILED(hrMap))
    {
        MDBG("DXGI: Map(pipeline_->cs_params_) failed", hrMap);
        return false;
    }
    memcpy(mapped.pData, &cb, sizeof(cb));
    ctx_->Unmap(pipeline_->cs_params_.Get(), 0);

    ID3D11ShaderResourceView *srvs[2] = {srvY, srvUV};
    ID3D11UnorderedAccessView *uavs[1] = {pipeline_->rt_uav_.Get()};
    ID3D11Buffer *cbs[1] = {pipeline_->cs_params_.Get()};

    ctx_->CSSetShader(cs_nv12_.Get(), nullptr, 0);
    ctx_->CSSetShaderResources(0, 2, srvs);
    ctx_->CSSetUnorderedAccessViews(0, 1, uavs, nullptr);
    ctx_->CSSetConstantBuffers(0, 1, cbs);

    UINT gx = (cur_w_ + 15) / 16;
    UINT gy = (cur_h_ + 15) / 16;
    ctx_->Dispatch(gx, gy, 1);

    // 清掉 CS 綁定，避免影響其他地方
    ID3D11ShaderResourceView *nullSrvs[2] = {nullptr, nullptr};
    ID3D11UnorderedAccessView *nullUavs[1] = {nullptr};
    ID3D11Buffer *nullCb[1] = {nullptr};

    ctx_->CSSetShader(nullptr, nullptr, 0);
    ctx_->CSSetShaderResources(0, 2, nullSrvs);
    ctx_->CSSetUnorderedAccessViews(0, 1, nullUavs, nullptr);
    ctx_->CSSetConstantBuffers(0, 1, nullCb);

    return true;
}

bool WinMFProvider::setPreview(const gcap_preview_desc_t &desc)
{
    if (!pipeline_)
        pipeline_ = std::make_unique<SharedScenePipeline>();
    return pipeline_->configurePreview(desc);
}

void WinMFProvider::release_preview_swapchain()
{
    if (pipeline_)
        pipeline_->release_preview_swapchain();
}

bool WinMFProvider::ensure_preview_swapchain(int w, int h)
{
    return pipeline_ && pipeline_->ensure_preview_swapchain(w, h);
}

bool WinMFProvider::present_preview()
{
    return pipeline_ && pipeline_->present_preview(cur_w_, cur_h_);
}
